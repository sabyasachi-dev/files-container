// Security: Utility to sanitize, validate, and isolate file content for AI sessions

const INJECTION_PATTERNS = [
  /ignore\s+(?:all\s+)?(?:previous\s+)?instructions/i,
  /forget\s+(?:all\s+)?(?:previous\s+)?instructions/i,
  /disregard\s+(?:all\s+)?(?:previous\s+)?instructions/i,
  /override\s+(?:previous\s+)?(?:system\s+)?(?:instructions|prompt)/i,
  /new\s+system\s+prompt/i,
  /jailbreak/i,
  /dan\s+mode/i,
  /do\s+anything\s+now/i,
  /act\s+as\s+a\s+(?:developer|system|new\s+persona)/i,
  /forget\s+(?:your\s+)?(?:persona|role)/i,
  /instead\s+of\s+(?:your\s+)?(?:normal|original|current)\s+instructions/i,
  /you\s+must\s+now\s+follow/i,
  /bypass\s+the\s+system/i,
  /read\s+the\s+instructions\s+below\s+instead/i,
  /ignore\s+the\s+(?:text|content|file)\s+below/i,
];

interface SecPDFPage {
  getJSActions(): Promise<Record<string, string[]> | null>;
  getTextContent(): Promise<{ items: Array<{ str: string }> }>;
}

interface SecPDFDocument {
  numPages: number;
  getJavaScript(): Promise<string[] | null>;
  getJSActions(): Promise<Record<string, string[]> | null>;
  getPage(pageNumber: number): Promise<SecPDFPage>;
}

/**
/**
 * Checks the raw binary stream of a PDF file for JavaScript signatures.
 */
export const checkPdfBinaryForJavaScript = (arrayBuffer: ArrayBuffer): void => {
  const decoder = new TextDecoder('utf-8', { fatal: false });
  const view = new Uint8Array(arrayBuffer);
  const text = decoder.decode(view);
  
  const jsSignatures = [
    /\/S\s*\/JavaScript/i,
    /\/JavaScript\s*(?:<<|\d+\s+\d+\s+R)/i,
    /\/ECMA\s*(?:<<|\d+\s+\d+\s+R)/i,
  ];

  for (const pattern of jsSignatures) {
    if (pattern.test(text)) {
      throw new Error(`Security Alert: Embedded JavaScript signature (${pattern.source}) detected in PDF binary structure.`);
    }
  }
};

/**
 * Checks the PDF document objects for any document-level JavaScript scripts.
 */
export const checkPdfDocumentJavaScript = async (pdf: SecPDFDocument): Promise<void> => {
  if (typeof pdf.getJavaScript === 'function') {
    const jsList = await pdf.getJavaScript();
    if (jsList && jsList.length > 0) {
      throw new Error('Security Alert: Active document-level JavaScript scripts detected inside PDF.');
    }
  }
};

/**
 * Checks the PDF document objects for document-level JavaScript trigger actions.
 */
export const checkPdfDocumentActions = async (pdf: SecPDFDocument): Promise<void> => {
  const jsActions = await pdf.getJSActions();
  if (jsActions && Object.keys(jsActions).length > 0) {
    throw new Error('Security Alert: Interactive document-level JavaScript trigger actions detected inside PDF.');
  }
};

/**
 * Checks individual pages of the PDF for page-level JavaScript actions.
 */
export const checkPdfPageActions = async (pdf: SecPDFDocument): Promise<void> => {
  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i);
    const pageActions = await page.getJSActions();
    if (pageActions && Object.keys(pageActions).length > 0) {
      throw new Error(`Security Alert: Interactive page-level JavaScript actions detected on page ${i} of PDF.`);
    }
  }
};

/**
 * Inspects a parsed PDF document and its raw array buffer for embedded JavaScript.
 * Throws a Security Alert error if any active content is detected.
 */
export const verifyPdfJavaScript = async (pdf: SecPDFDocument, arrayBuffer: ArrayBuffer): Promise<void> => {
  // 1. Scan binary data for signatures
  checkPdfBinaryForJavaScript(arrayBuffer);

  // 2. Scan document-level scripts
  await checkPdfDocumentJavaScript(pdf);

  // 3. Scan document-level actions
  await checkPdfDocumentActions(pdf);

  // 4. Scan page-level actions
  await checkPdfPageActions(pdf);
};

/**
 * Parses and extracts text content from an uploaded File.
 * Supports PDF extraction via pdfjs-dist and general text extraction via FileReader.
 */
export const extractTextFromFile = async (file: File): Promise<string> => {
  const fileExtension = file.name.split('.').pop()?.toLowerCase();

  if (fileExtension === 'pdf') {
    // Dynamically import pdfjs-dist to avoid SSR window/document errors
    const pdfjsLib = await import('pdfjs-dist');
    pdfjsLib.GlobalWorkerOptions.workerSrc = `https://unpkg.com/pdfjs-dist@${pdfjsLib.version}/build/pdf.worker.min.mjs`;

    const arrayBuffer = await file.arrayBuffer();
    const arrayBufferCopy = arrayBuffer.slice(0);

    // 2. Structured Parse Check via PDF.js
    const pdfRaw = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
    const pdf = pdfRaw as unknown as SecPDFDocument;

    // Verify PDF JavaScript security
    await verifyPdfJavaScript(pdf, arrayBufferCopy);

    let fullText = '';

    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const textContent = await page.getTextContent();
      const pageText = textContent.items.map((item: { str: string }) => item.str).join(' ');
      fullText += pageText + '\n';
    }
    return fullText;
  } else {
    // For text-based formats (.txt, .js, .py, .java, .json)
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (event) => {
        resolve(event.target?.result as string || '');
      };
      reader.onerror = (error) => reject(error);
      reader.readAsText(file);
    });
  }
};

/**
 * Sanitizes the raw file content to prevent escaping bounding tags.
 * Also removes potentially dangerous HTML/XML tags.
 */
export const sanitizeFileContent = (content: string): string => {
  if (!content) return '';

  // 1. Remove XML/HTML tags to prevent boundary escaping
  let sanitized = content.replace(/<[^>]*>?/gm, '');

  // 2. Remove delimiter text that might be used to trick the AI or escape encapsulation
  sanitized = sanitized
    .replace(/<uploaded_document>/gi, '')
    .replace(/<\/uploaded_document>/gi, '')
    .replace(/<uploaded_file>/gi, '')
    .replace(/<\/uploaded_file>/gi, '')
    .replace(/\[START OF UNTRUSTED USER-UPLOADED FILE CONTENT\]/gi, '')
    .replace(/\[END OF UNTRUSTED USER-UPLOADED FILE CONTENT\]/gi, '')
    .replace(/--- BEGIN /gi, '')
    .replace(/--- END /gi, '');

  // 3. Enforce a reasonable length limit (e.g., 20000 characters)
  const MAX_LENGTH = 20000;
  if (sanitized.length > MAX_LENGTH) {
    sanitized = sanitized.substring(0, MAX_LENGTH) + '\n...[CONTENT TRUNCATED]';
  }

  return sanitized.trim();
};

/**
 * Validates the file content by searching for common prompt injection patterns.
 */
export const detectPromptInjection = (content: string): { isInjected: boolean; reason?: string } => {
  if (!content) return { isInjected: false };

  for (const pattern of INJECTION_PATTERPS || []) {
    // We run safety checks on the raw content as well as the sanitized content
    if (pattern.test(content)) {
      return {
        isInjected: true,
        reason: `Potential prompt injection instruction detected matching pattern: ${pattern.toString()}`
      };
    }
  }

  return { isInjected: false };
};

// Fix typo in variable name by defining a fallback mapping or using it correctly
const INJECTION_PATTERPS = INJECTION_PATTERNS;

/**
 * Formats the content with clear isolation markers to isolate the untrusted input.
 */
export const wrapIsolatedContent = (content: string): string => {
  return `<uploaded_document>\n[START OF UNTRUSTED USER-UPLOADED FILE CONTENT]\n${content}\n[END OF UNTRUSTED USER-UPLOADED FILE CONTENT]\n</uploaded_document>`;
};
