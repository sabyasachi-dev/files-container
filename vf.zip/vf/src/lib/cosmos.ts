import { CosmosClient } from "@azure/cosmos";

const endpoint = process.env.COSMOS_DB_ENDPOINT;
const key = process.env.COSMOS_DB_KEY;
const databaseId = process.env.COSMOS_DB_DATABASE_ID || "VirtualFacilitatorDB";
const containerId = process.env.COSMOS_DB_CONTAINER_ID || "Feedback";

let client: CosmosClient | null = null;
let isConfigured = false;

if (endpoint && key) {
  try {
    client = new CosmosClient({ endpoint, key });
    isConfigured = true;
    console.log("Azure Cosmos DB Client initialized successfully.");
  } catch (error) {
    console.error("Failed to initialize Azure Cosmos DB Client:", error);
  }
} else {
  console.warn(
    "Azure Cosmos DB is not configured. Missing COSMOS_DB_ENDPOINT or COSMOS_DB_KEY in environment variables. Falling back to Mock DB for development/testing."
  );
}

export interface FeedbackItem {
  qualityRating: number;
  accuracyRating: number;
  avatarRating: number;
  comments: string;
  timestamp: string;
  profile: {
    name?: string;
    role?: string;
    domain?: string;
    techStack?: string[];
  } | null;
}

/**
 * Saves user feedback to Azure Cosmos DB.
 * If credentials are not configured, logs the payload to the console and simulates a successful write.
 */
export async function saveFeedback(feedbackData: FeedbackItem) {
  if (!isConfigured || !client) {
    console.log(
      "[MOCK DB SAVE] Simulating Azure Cosmos DB write. Saved feedback details:",
      JSON.stringify(feedbackData, null, 2)
    );
    return {
      id: `mock-feedback-${Date.now()}`,
      ...feedbackData,
      _mocked: true,
    };
  }

  try {
    // 1. Ensure the database exists
    const { database } = await client.databases.createIfNotExists({ id: databaseId });

    // 2. Ensure the container exists. We partition by '/id' as it guarantees even partition distribution.
    const { container } = await database.containers.createIfNotExists({
      id: containerId,
      partitionKey: "/id",
    });

    // 3. Create the document item
    const itemToCreate = {
      id: crypto.randomUUID(),
      ...feedbackData,
    };

    const { resource } = await container.items.create(itemToCreate);
    console.log(`[COSMOS DB SUCCESS] Saved feedback item. ID: ${resource?.id}`);
    return resource;
  } catch (error) {
    console.error("[COSMOS DB ERROR] Failed to save feedback item:", error);
    throw new Error("Database persistence operation failed.");
  }
}
