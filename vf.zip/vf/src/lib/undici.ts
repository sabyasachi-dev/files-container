import { Agent, setGlobalDispatcher } from 'undici';
import fs from 'fs';
import path from 'path';

const appEnv = process.env.APP_ENV || 'local';
const certPath = path.join(process.cwd(), 'configs', appEnv, 'ca.crt');
const allowInsecureTls = process.env.ALLOW_INSECURE_TLS === 'true';

let ca: Buffer | undefined;

if (fs.existsSync(certPath)) {
  try {
    ca = fs.readFileSync(certPath);
    console.log(`[UNDICI] Using CA certificate: ca.crt (${appEnv})`);
  } catch (error) {
    console.error(`[UNDICI] Failed to read CA cert (ca.crt) for ${appEnv}:`, error);
  }
} else {
  console.warn(`[UNDICI] Certificate not found at path: ${certPath}`);
}

try {
  const agent = new Agent({
    connect: {
      ca,
      rejectUnauthorized: !allowInsecureTls,
    },
  });

  setGlobalDispatcher(agent);

  if (allowInsecureTls) {
    console.warn('[UNDICI] TLS certificate validation is disabled for this runtime. Only use this for local/home-network development.');
  }
} catch (error) {
  console.error('[UNDICI] Failed to initialize Undici dispatcher:', error);
}
