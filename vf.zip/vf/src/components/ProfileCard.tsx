import { Edit2 } from 'lucide-react';

export default function ProfileCard() {
  return (
    <div className="bg-white border border-slate-200 rounded-lg p-6 relative shadow-sm mb-8">
      <button className="absolute top-6 right-6 text-slate-400 hover:text-slate-800"><Edit2 size={16}/></button>
      <h3 className="text-lg font-bold text-slate-900 mb-4">Rajan V. Sahatrabudhe</h3>
      <div className="grid grid-cols-[100px_1fr] gap-y-1 text-sm">
        <div className="text-slate-500">Role:</div><div className="text-slate-800">Backend Developer</div>
        <div className="text-slate-500">Domain:</div><div className="text-slate-800">BFS</div>
        <div className="text-slate-500">Tech Stack:</div><div className="text-slate-800">Java, Spring, Kafka</div>
      </div>
    </div>
  );
}