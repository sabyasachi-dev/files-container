'use client';
import Image from 'next/image';
import { Menu, LogOut } from 'lucide-react';
import { basePath } from '@/utils/basePath';
import { usePathname } from 'next/navigation';
import { useState, useEffect } from 'react';

export default function Header() {
  const pathname = usePathname();
  const isHome = pathname === '/'; // Check if we are on the home page

  const [hidden, setHidden] = useState(false);

  // Handle Scroll to hide header on EVERY page
  useEffect(() => {
    let lastScroll = 0;
    const handleScroll = () => {
      const current = window.scrollY;
      // Hide if scrolling down more than 50px
      setHidden(current > lastScroll && current > 50);
      lastScroll = current;
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []); // The effect now runs regardless of the route

  const handleLogout = () => {
    // Clear session context if any
    localStorage.removeItem('virtual_facilitator_context');
    // Redirect to oauth2-proxy sign out endpoint, passing the MS logout URL in the rd parameter.
    // This forces the proxy to send the user to Microsoft to destroy the SSO session, 
    // breaking the ERR_TOO_MANY_REDIRECTS auto-login loop.
    const msLogoutUrl = encodeURIComponent('https://login.microsoftonline.com/common/oauth2/v2.0/logout');
    window.location.href = `/oauth2/sign_out?rd=${msLogoutUrl}`;
  };

  return (
    <nav className={`bg-white shadow-sm border-b border-gray-100 fixed top-0 w-full z-50 flex justify-between items-center px-8 py-4 transition-transform duration-300 ${hidden ? '-translate-y-full' : 'translate-y-0'}`}>
      <div className="flex items-center gap-6">
        <Image
          src={`${basePath}/assets/LTM_Coral.png`}
          alt="LTM Coral Logo"
          width={80}
          height={32}
          className="h-6 w-auto object-contain"
          priority
        />
        <div className="h-6 w-[2px] bg-[#ff5c4d] rounded-full"></div>
        <div className="flex flex-col items-center">
          <div className="text-3xl font-bold tracking-tighter text-[#ff5c4d] leading-none">Virtual Facilitator</div>
          <div className="text-[9px] font-medium text-slate-700 mt-1 tracking-wide">Your Intelligent Virtual Facilitator</div>
        </div>
      </div>

      <div className="flex items-center gap-4">
        {/* Conditionally render the menu icon ONLY on the home page */}
        {isHome && (
          <button className="hidden text-slate-800 hover:text-slate-600 transition-colors cursor-pointer">
            <Menu className="w-8 h-8" strokeWidth={1.5} />
          </button>
        )}

        {/* Logout Button */}
        <button 
          onClick={handleLogout}
          className="text-slate-800 hover:text-slate-600 transition-colors cursor-pointer flex items-center"
          title="Logout"
        >
          <LogOut className="w-5 h-5" strokeWidth={1.5} />
        </button>
      </div>
    </nav>
  );
}