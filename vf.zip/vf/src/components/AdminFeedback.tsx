'use client';

import React, { useState } from 'react';
import { Plus, Edit2, Trash2, X, Save, Download } from 'lucide-react';
import { FeedbackItem } from '../lib/cosmos';

type FeedbackWithId = FeedbackItem & { id: string };

const initialMockData: FeedbackWithId[] = [
  {
    id: "1",
    qualityRating: 5,
    accuracyRating: 4,
    avatarRating: 5,
    comments: "Great experience overall! The avatar felt very natural.",
    timestamp: new Date().toISOString(),
    profile: {
      name: "Alice Johnson",
      role: "Developer",
      domain: "Tech",
      techStack: ["React", "Node.js"]
    }
  },
  {
    id: "2",
    qualityRating: 3,
    accuracyRating: 3,
    avatarRating: 4,
    comments: "It was okay, but the responses were a bit slow.",
    timestamp: new Date(Date.now() - 86400000).toISOString(),
    profile: {
      name: "Bob Smith",
      role: "Designer",
      domain: "Creative",
      techStack: ["Figma"]
    }
  }
];

export default function AdminFeedback() {
  const [feedbacks, setFeedbacks] = useState<FeedbackWithId[]>(initialMockData);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingFeedback, setEditingFeedback] = useState<FeedbackWithId | null>(null);
  
  // Delete modal states
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [feedbackToDelete, setFeedbackToDelete] = useState<string | null>(null);

  // Form states
  const [formData, setFormData] = useState<Partial<FeedbackWithId>>({});

  const handleOpenModal = (feedback?: FeedbackWithId) => {
    if (feedback) {
      setEditingFeedback(feedback);
      setFormData(feedback);
    } else {
      setEditingFeedback(null);
      setFormData({
        qualityRating: 5,
        accuracyRating: 5,
        avatarRating: 5,
        comments: "",
        profile: { name: "", role: "", domain: "", techStack: [] }
      });
    }
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingFeedback(null);
  };

  const handleSave = () => {
    if (editingFeedback) {
      // Update
      setFeedbacks(prev => prev.map(f => f.id === editingFeedback.id ? { ...f, ...formData } as FeedbackWithId : f));
    } else {
      // Add
      const newFeedback: FeedbackWithId = {
        ...(formData as FeedbackWithId),
        id: Math.random().toString(36).substring(7),
        timestamp: new Date().toISOString()
      };
      setFeedbacks(prev => [newFeedback, ...prev]);
    }
    handleCloseModal();
  };

  const confirmDelete = (id: string) => {
    setFeedbackToDelete(id);
    setIsDeleteModalOpen(true);
  };

  const handleDelete = () => {
    if (feedbackToDelete) {
      setFeedbacks(prev => prev.filter(f => f.id !== feedbackToDelete));
    }
    setIsDeleteModalOpen(false);
    setFeedbackToDelete(null);
  };

  const handleCancelDelete = () => {
    setIsDeleteModalOpen(false);
    setFeedbackToDelete(null);
  };

  const handleExport = () => {
    // Convert feedbacks to CSV
    const headers = ['ID', 'Name', 'Role', 'Domain', 'Tech Stack', 'Quality', 'Accuracy', 'Avatar', 'Comments', 'Date'];
    
    const csvContent = [
      headers.join(','),
      ...feedbacks.map(f => [
        f.id,
        `"${(f.profile?.name || '').replace(/"/g, '""')}"`,
        `"${(f.profile?.role || '').replace(/"/g, '""')}"`,
        `"${(f.profile?.domain || '').replace(/"/g, '""')}"`,
        `"${(f.profile?.techStack?.join('; ') || '').replace(/"/g, '""')}"`,
        f.qualityRating,
        f.accuracyRating,
        f.avatarRating,
        `"${(f.comments || '').replace(/"/g, '""')}"`,
        `"${new Date(f.timestamp).toLocaleDateString()}"`
      ].join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `feedbacks_export_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="w-full max-w-7xl mx-auto p-6 text-white min-h-screen">
      <div className="flex justify-between items-center mb-8 mt-10">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-white">Feedback Management</h1>
          <p className="text-gray-400 mt-1">View and manage user feedback submissions.</p>
        </div>
        <div className="flex items-center gap-3">
          <button 
            onClick={handleExport}
            className="flex items-center gap-2 bg-gray-800 hover:bg-gray-700 text-white px-4 py-2 rounded-lg font-medium transition-all border border-gray-700 cursor-pointer"
          >
            <Download className="w-5 h-5 cursor-pointer" />
            Export CSV
          </button>
          <button 
            onClick={() => handleOpenModal()}
            className="flex items-center gap-2 bg-[#3b46ff] hover:bg-blue-600 text-white px-4 py-2 rounded-lg font-medium transition-all btn-glow cursor-pointer"
          >
            <Plus className="w-5 h-5 cursor-pointer" />
            Add Feedback
          </button>
        </div>
      </div>

      <div className="glass-panel rounded-xl overflow-hidden border border-gray-800 shadow-2xl relative z-10">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-gray-700 bg-black/40">
                <th className="px-6 py-4 font-semibold text-gray-300">User Profile</th>
                <th className="px-6 py-4 font-semibold text-gray-300">Ratings (Q / A / Av)</th>
                <th className="px-6 py-4 font-semibold text-gray-300">Comments</th>
                <th className="px-6 py-4 font-semibold text-gray-300">Date</th>
                <th className="px-6 py-4 font-semibold text-gray-300 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {feedbacks.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-6 py-8 text-center text-gray-500">
                    No feedbacks found.
                  </td>
                </tr>
              ) : (
                feedbacks.map((item) => (
                  <tr key={item.id} className="border-b border-gray-800 hover:bg-white/5 transition-colors">
                    <td className="px-6 py-4">
                      <div className="font-medium text-white">{item.profile?.name || 'Anonymous'}</div>
                      <div className="text-xs text-gray-400">{item.profile?.role || 'N/A'} {item.profile?.domain ? `• ${item.profile?.domain}` : ''}</div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex gap-2">
                        <span className="bg-blue-900/50 text-blue-300 px-2 py-1 rounded text-xs font-medium border border-blue-800/50">Q: {item.qualityRating}</span>
                        <span className="bg-green-900/50 text-green-300 px-2 py-1 rounded text-xs font-medium border border-green-800/50">A: {item.accuracyRating}</span>
                        <span className="bg-purple-900/50 text-purple-300 px-2 py-1 rounded text-xs font-medium border border-purple-800/50">Av: {item.avatarRating}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 max-w-xs truncate text-gray-300" title={item.comments}>
                      {item.comments || '-'}
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-400 whitespace-nowrap">
                      {new Date(item.timestamp).toLocaleDateString()}
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex justify-end gap-3">
                        <button 
                          onClick={() => handleOpenModal(item)}
                          className="p-2 text-gray-400 hover:text-blue-400 hover:bg-blue-500/10 rounded-lg transition-colors cursor-pointer"
                          title="Edit"
                        >
                          <Edit2 className="w-4 h-4 cursor-pointer" />
                        </button>
                        <button 
                          onClick={() => confirmDelete(item.id)}
                          className="p-2 text-gray-400 hover:text-[#ff5c4d] hover:bg-[#ff5c4d]/10 rounded-lg transition-colors cursor-pointer"
                          title="Delete"
                        >
                          <Trash2 className="w-4 h-4 cursor-pointer" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Overlay */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-md p-4">
          <div 
            className="glass-panel w-full max-w-lg rounded-2xl border border-gray-700 shadow-[0_0_50px_-12px_rgba(0,0,0,0.8)] p-6 flex flex-col max-h-[90vh] overflow-y-auto no-scrollbar relative"
            style={{ backgroundColor: '#1a1a1e' }}
          >
            {/* Modal Header */}
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold text-white tracking-tight">
                {editingFeedback ? 'Edit Feedback' : 'Add New Feedback'}
              </h2>
              <button 
                onClick={handleCloseModal} 
                className="text-gray-400 hover:text-white hover:bg-white/10 p-1.5 rounded-md transition-colors cursor-pointer"
              >
                <X className="w-5 h-5 cursor-pointer" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="space-y-5 flex-1">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-1.5">Name</label>
                  <input 
                    type="text" 
                    value={formData.profile?.name || ''}
                    onChange={(e) => setFormData({...formData, profile: {...formData.profile, name: e.target.value}})}
                    className="w-full bg-black/40 border border-gray-700/80 rounded-lg px-4 py-2.5 text-white focus:outline-none focus:border-[#3b46ff] focus:ring-1 focus:ring-[#3b46ff] transition-all"
                    placeholder="John Doe"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-1.5">Role</label>
                  <input 
                    type="text" 
                    value={formData.profile?.role || ''}
                    onChange={(e) => setFormData({...formData, profile: {...formData.profile, role: e.target.value}})}
                    className="w-full bg-black/40 border border-gray-700/80 rounded-lg px-4 py-2.5 text-white focus:outline-none focus:border-[#3b46ff] focus:ring-1 focus:ring-[#3b46ff] transition-all"
                    placeholder="Engineer"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-1.5">Quality (1-5)</label>
                  <input 
                    type="number" min="1" max="5"
                    value={formData.qualityRating || 5}
                    onChange={(e) => setFormData({...formData, qualityRating: Number(e.target.value)})}
                    className="w-full bg-black/40 border border-gray-700/80 rounded-lg px-4 py-2.5 text-white focus:outline-none focus:border-[#3b46ff] focus:ring-1 focus:ring-[#3b46ff] transition-all"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-1.5">Accuracy (1-5)</label>
                  <input 
                    type="number" min="1" max="5"
                    value={formData.accuracyRating || 5}
                    onChange={(e) => setFormData({...formData, accuracyRating: Number(e.target.value)})}
                    className="w-full bg-black/40 border border-gray-700/80 rounded-lg px-4 py-2.5 text-white focus:outline-none focus:border-[#3b46ff] focus:ring-1 focus:ring-[#3b46ff] transition-all"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-1.5">Avatar (1-5)</label>
                  <input 
                    type="number" min="1" max="5"
                    value={formData.avatarRating || 5}
                    onChange={(e) => setFormData({...formData, avatarRating: Number(e.target.value)})}
                    className="w-full bg-black/40 border border-gray-700/80 rounded-lg px-4 py-2.5 text-white focus:outline-none focus:border-[#3b46ff] focus:ring-1 focus:ring-[#3b46ff] transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1.5">Comments</label>
                <textarea 
                  rows={4}
                  value={formData.comments || ''}
                  onChange={(e) => setFormData({...formData, comments: e.target.value})}
                  className="w-full bg-black/40 border border-gray-700/80 rounded-lg px-4 py-2.5 text-white focus:outline-none focus:border-[#3b46ff] focus:ring-1 focus:ring-[#3b46ff] transition-all resize-none"
                  placeholder="Share any thoughts or feedback..."
                />
              </div>
            </div>

            {/* Modal Footer */}
            <div className="mt-8 flex justify-end gap-3 pt-4 border-t border-gray-700/50">
              <button 
                onClick={handleCloseModal}
                className="px-5 py-2.5 rounded-lg font-medium text-gray-300 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button 
                onClick={handleSave}
                className="flex items-center gap-2 bg-[#3b46ff] hover:bg-blue-600 text-white px-5 py-2.5 rounded-lg font-medium transition-all btn-glow shadow-lg shadow-blue-500/20 cursor-pointer"
              >
                <Save className="w-4 h-4 cursor-pointer" />
                Save Feedback
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal Overlay */}
      {isDeleteModalOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/40 backdrop-blur-sm p-4">
          <div 
            className="glass-panel w-full max-w-[300px] rounded-xl border border-gray-700/80 shadow-2xl p-5 flex flex-col relative"
            style={{ backgroundColor: '#1a1a1e' }}
          >
            <h2 className="text-base font-bold text-white tracking-tight mb-2 flex items-center gap-2">
              <Trash2 className="w-4 h-4 text-[#ff5c4d]" />
              Delete Feedback?
            </h2>
            <p className="text-gray-400 mb-5 text-sm leading-relaxed">
              This action cannot be undone.
            </p>
            
            <div className="flex justify-end gap-2">
              <button 
                onClick={handleCancelDelete}
                className="px-4 py-1.5 rounded-md text-sm font-medium text-gray-300 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button 
                onClick={handleDelete}
                className="px-4 py-1.5 rounded-md text-sm font-medium bg-[#ff5c4d] hover:bg-red-600 text-white transition-all shadow-md shadow-red-500/20 cursor-pointer"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
