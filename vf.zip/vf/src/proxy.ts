import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

export async function proxy(request: NextRequest) {
  const { pathname } = request.nextUrl;
  
  // 1. Skip middleware for static assets, images, and API routes
  if (pathname.startsWith('/_next') || pathname.startsWith('/api') || pathname.includes('.')) {
    return NextResponse.next();
  }

  // 2. Get the authenticated email passed by NGINX
  const email = request.headers.get('x-email');
  if (!email) {
    // Let NGINX/oauth2-proxy handle the unauthenticated state
    return NextResponse.next();
  }

  // 2.5 Check if the feature flag is enabled in .env
  if (process.env.ENABLE_CONCURRENT_SESSION_LIMIT !== 'true') {
    return NextResponse.next();
  }

  // 3. Get the device/session tracking cookie
  let deviceId = request.cookies.get('global_session_id')?.value;
  let isNewSession = false;

  if (!deviceId) {
    // Edge runtime supports crypto.randomUUID natively, no 'uuid' package needed
    deviceId = crypto.randomUUID();
    isNewSession = true;
  }

  // 4. Validate against Redis via our internal API route
  // We MUST do this because middleware runs on Edge Runtime, which cannot use 'ioredis' directly.
  try {
    const verifyUrl = new URL('/api/auth/verify-session', request.url);
    const verifyResponse = await fetch(verifyUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, deviceId, isNewSession })
    });

    const data = await verifyResponse.json();

    if (!data.valid) {
      console.warn(`[KICKED] ${email} disconnected due to a newer login on another device.`);
      
      // Stop the tug-of-war loop: redirect to the proxy sign-out endpoint
      // Passing the MS logout URL securely destroys the SSO session so they don't auto-login.
      const msLogoutUrl = encodeURIComponent('https://login.microsoftonline.com/common/oauth2/v2.0/logout');
      const kickResponse = NextResponse.redirect(new URL(`/oauth2/sign_out?rd=${msLogoutUrl}`, request.url));
      
      // Clear all cookies before redirect
      request.cookies.getAll().forEach(cookie => {
        kickResponse.cookies.delete(cookie.name);
      });
      
      return kickResponse;
    }

  } catch (error) {
    console.error('Session validation failed:', error);
    // If Redis verification fails, fail open to avoid locking users out
    return NextResponse.next();
  }

  // 5. Session matches or is new. Let them through.
  const response = NextResponse.next();

  if (isNewSession) {
    console.log(`[NEW SESSION] ${email} logged in.`);
    response.cookies.set('global_session_id', deviceId, {
      httpOnly: true,
      secure: true, // Assuming HTTPS via NGINX
      sameSite: 'lax',
      path: '/',    // Global cookie
    });
  }

  return response;
}
