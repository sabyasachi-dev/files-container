'use client';
import Link from 'next/link';
import Image from 'next/image';
import { Download, Star, Loader2 } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { useState, useEffect } from 'react';
import { jsPDF } from 'jspdf';
import Header from '@/components/Header';
import { basePath } from '@/utils/basePath';

// Helper function to loosely validate meaningful text vs garbage (keyboard mashing)
const isValidComment = (text: string) => {
  if (!text.trim()) return false;

  // Must contain at least one valid word (3+ letters)
  if (!/[a-zA-Z]{3,}/.test(text)) return false;

  // Must contain at least one vowel (a, e, i, o, u, y)
  if (!/[aeiouyAEIOUY]/.test(text)) return false;

  // Reject long strings without spaces (likely keyboard mashing)
  const words = text.split(/\s+/);
  if (words.some(word => word.length > 25)) return false;

  // Reject 3+ consecutive identical characters (e.g., "aaa" or "ddd")
  if (/(.)\1{2,}/.test(text)) return false;

  // Reject 6+ consecutive consonants (another strong sign of keyboard mashing)
  if (/[bcdfghjklmnpqrstvwxzBCDFGHJKLMNPQRSTVWXZ]{6,}/.test(text)) return false;

  return true;
};

export default function SessionSummary() {
  const router = useRouter();

  // --- Feedback Popup State ---
  const [showFeedback, setShowFeedback] = useState(false);
  const [hasSubmittedFeedback, setHasSubmittedFeedback] = useState(false); // Track if feedback is completed
  const [qualityRating, setQualityRating] = useState(0);
  const [accuracyRating, setAccuracyRating] = useState(0);
  const [avatarRating, setAvatarRating] = useState(0);
  const [comments, setComments] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  // Trigger popup after 5 sec (5,000 ms)
  useEffect(() => {
    const timer = setTimeout(() => {
      setShowFeedback(true);
    }, 5000);

    return () => clearTimeout(timer);
  }, []);

  const handleFeedbackSubmit = async () => {
    setIsSubmitting(true);
    setSubmitError(null);

    // Fetch profile context from local storage
    let profile = null;
    try {
      const contextStr = localStorage.getItem('virtual_facilitator_context');
      if (contextStr) {
        const contextData = JSON.parse(contextStr);
        profile = contextData.profile || null;
      }
    } catch (err) {
      console.error("Failed to parse context for feedback submission:", err);
    }

    try {
      const response = await fetch(`${basePath}/api/submit-feedback`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          qualityRating,
          accuracyRating,
          avatarRating,
          comments,
          profile,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to submit feedback.');
      }

      setHasSubmittedFeedback(true); // Unlock the download button
      setShowFeedback(false);
    } catch (err: any) {
      console.error("Error submitting feedback:", err);
      setSubmitError(err.message || 'An unexpected error occurred while saving your feedback.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // --- PDF Download Logic ---
  const handleDownloadSummary = () => {
    const contextStr = localStorage.getItem('virtual_facilitator_context');

    if (!contextStr) {
      alert("No session data found to download.");
      return;
    }

    const contextData = JSON.parse(contextStr);
    const doc = new jsPDF();
    const margin = 20;
    const pageWidth = doc.internal.pageSize.getWidth();
    const maxLineWidth = pageWidth - margin * 2;
    let yPos = 20;

    // --- Helper to Check Page Overflow ---
    const checkPageBreak = (extraSpace = 0) => {
      if (yPos + extraSpace > doc.internal.pageSize.getHeight() - 20) {
        doc.addPage();
        yPos = 20;
      }
    };

    // --- Helper for Date Formatting ---
    const d = new Date();
    const dateNum = d.getDate();
    const nth = (day: number) => {
      if (day > 3 && day < 21) return 'th';
      switch (day % 10) {
        case 1: return "st";
        case 2: return "nd";
        case 3: return "rd";
        default: return "th";
      }
    };
    const dateStr = `${dateNum}${nth(dateNum)} ${d.toLocaleString('default', { month: 'long' })} ${d.getFullYear()}`;
    const timeStr = d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }) + (d.getHours() >= 12 ? ' PM' : ' AM');

    // --- 1. Document Header ---
    // Centered Title
    doc.setFont("helvetica", "bold");
    doc.setFontSize(18);
    doc.setTextColor(0, 32, 96); // Dark blue as per image
    const title = "Virtual Avatar Summary Report";
    const titleWidth = doc.getTextWidth(title);
    doc.text(title, (pageWidth - titleWidth) / 2, yPos);
    yPos += 15;

    // Date and Timestamp Setup
    doc.setFontSize(11);
    doc.setTextColor(0, 0, 0);

    // Render Date (Bold label, normal value)
    doc.setFont("helvetica", "bold");
    doc.text("Date: ", margin, yPos);
    const dateLabelWidth = doc.getTextWidth("Date: ");
    doc.setFont("helvetica", "normal");
    doc.text(dateStr, margin + dateLabelWidth, yPos);

    // Render Timestamp (Bold label, normal value, aligned right)
    doc.setFont("helvetica", "bold");
    const tsLabelWidth = doc.getTextWidth("Timestamp: ");
    doc.setFont("helvetica", "normal");
    const tsValWidth = doc.getTextWidth(timeStr);
    const totalTsWidth = tsLabelWidth + tsValWidth;
    const startX = pageWidth - margin - totalTsWidth;

    doc.setFont("helvetica", "bold");
    doc.text("Timestamp: ", startX, yPos);
    doc.setFont("helvetica", "normal");
    doc.text(timeStr, startX + tsLabelWidth, yPos);
    yPos += 10;

    // Render Category (Bold label, normal value)
    const categoryVal = contextData.selectedCategory || "Technical";
    const formattedCategory = categoryVal.charAt(0).toUpperCase() + categoryVal.slice(1);

    doc.setFont("helvetica", "bold");
    doc.text("Category: ", margin, yPos);
    const catLabelWidth = doc.getTextWidth("Category: ");
    doc.setFont("helvetica", "normal");
    doc.text(formattedCategory, margin + catLabelWidth, yPos);
    yPos += 15;

    // --- 2. Learner Profile ---
    if (contextData.profile) {
      checkPageBreak(30);
      doc.setFont("helvetica", "bold");
      doc.text("Learner Profile:", margin, yPos);
      yPos += 7;

      doc.setFont("helvetica", "normal");
      doc.text(`Name: ${contextData.profile.name}`, margin, yPos);
      yPos += 6;
      doc.text(`Role: ${contextData.profile.role} | Domain: ${contextData.profile.domain}`, margin, yPos);
      yPos += 6;
      doc.text(`Tech Stack: ${contextData.profile.techStack?.join(", ")}`, margin, yPos);
      yPos += 12;
    }

    // --- 3. Initial Setup Data (Q&A or File) ---
    if (contextData.submissionType === 'manual_qa' && contextData.data?.qa_pairs) {
      checkPageBreak(20);
      doc.setFont("helvetica", "bold");
      doc.text("Initial Q&A Setup:", margin, yPos);
      yPos += 8;

      doc.setFont("helvetica", "normal");
      contextData.data.qa_pairs.forEach((pair: any) => {
        // Print Question
        const qLines = doc.splitTextToSize(`Q: ${pair.question}`, maxLineWidth);
        qLines.forEach((line: string) => {
          checkPageBreak(6);
          doc.setFont("helvetica", "bold");
          doc.text(line, margin, yPos);
          yPos += 6;
        });

        // Print Answer
        const aLines = doc.splitTextToSize(`A: ${pair.answer}`, maxLineWidth);
        aLines.forEach((line: string) => {
          checkPageBreak(6);
          doc.setFont("helvetica", "normal");
          doc.text(line, margin, yPos);
          yPos += 6;
        });
        yPos += 4; // Space between Q&A pairs
      });
      yPos += 8;
    } else if (contextData.submissionType === 'file_upload' && contextData.data?.fileContent) {
      checkPageBreak(20);
      doc.setFont("helvetica", "bold");
      doc.text("Uploaded Context Summary:", margin, yPos);
      yPos += 8;

      doc.setFont("helvetica", "normal");
      const fileLines = doc.splitTextToSize(contextData.data.fileContent, maxLineWidth);
      fileLines.forEach((line: string) => {
        checkPageBreak(6);
        doc.text(line, margin, yPos);
        yPos += 6;
      });
      yPos += 8;
    }

    // --- 4. Session Conversation History ---
    if (contextData.session_history && contextData.session_history.length > 0) {
      checkPageBreak(20);
      doc.setFont("helvetica", "bold");
      doc.text("Session Conversation:", margin, yPos);
      yPos += 8;

      contextData.session_history.forEach((msg: any) => {
        const role = msg.role === 'user' ? 'Me' : 'VIRTUAL FACILITATOR'; // Updated here to match Virtual Facilitator
        const time = new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

        // Print Name & Time
        checkPageBreak(6);
        doc.setFont("helvetica", "bold");
        doc.text(`[${time}] ${role}:`, margin, yPos);
        yPos += 6;

        // Print Message Content
        doc.setFont("helvetica", "normal");
        const splitText = doc.splitTextToSize(msg.content, maxLineWidth);

        splitText.forEach((line: string) => {
          checkPageBreak(6);
          doc.text(line, margin, yPos);
          yPos += 6;
        });
        yPos += 4; // Space between messages
      });
    }

    // Save the PDF
    const fileDay = d.getDate().toString().padStart(2, '0');
    const fileMonth = (d.getMonth() + 1).toString().padStart(2, '0');
    const fileYear = d.getFullYear();
    const fileDateStr = `${fileDay}-${fileMonth}-${fileYear}`;

    const fileTimeStr = d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true })
      .replace(/:/g, '-')
      .replace(/ /g, '_');

    doc.save(`Virtual_Avatar_Summary_Report_${fileDateStr}_${fileTimeStr}.pdf`);
  };

  return (
    <div className="min-h-screen relative bg-slate-50 font-source-sans flex flex-col">

      {/* 1. Background Image with Blur Effect */}
      <div className="absolute inset-0 z-0 overflow-hidden">
        <Image
          src={`${basePath}/assets/avatar-preview.webp`}
          alt="Background"
          fill
          className="object-cover filter blur-[8px] brightness-[0.35] scale-110"
          priority
        />
      </div>

      {/* 2. Global Header Component */}
      <div className="relative z-50">
        <Header />
      </div>

      {/* 3. Main Content Overlay */}
      <main className="relative z-10 flex-grow flex items-center justify-center px-4 pt-20">

        <div className="bg-white border border-slate-200 rounded-lg p-10 max-w-2xl w-full shadow-lg">

          {/* Label */}
          <div className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-4">
            SUMMARY
          </div>

          {/* Title */}
          <h1 className="text-3xl font-semibold text-slate-900 mb-6">
            Your session is complete! Great progress today.
          </h1>

          {/* Paragraph Content */}
          <p className="text-slate-600 leading-relaxed font-light mb-10 text-lg text-left">
            At the end of your session, Virtual Facilitator generates a <strong className="font-semibold text-slate-900">Session Summary Report</strong> capturing key discussion points, concepts learned, and next steps to support your continued training journey.
          </p>

          <p className="text-slate-600 leading-relaxed font-light mb-10 text-lg text-left">
            To continue this conversation later, please download your Session Summary Report. You'll need to upload this file to seamlessly resume from where you left off
          </p>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-4">

            {/* Exit Button */}
            <Link
              href="/"
              className="border border-slate-300 text-slate-700 hover:text-slate-900 hover:bg-slate-100 font-medium px-8 py-3 rounded-full transition-all text-base min-w-[200px] text-center cursor-pointer"
            >
              Exit without download
            </Link>

            {/* Download Button */}
            <button
              onClick={handleDownloadSummary}
              disabled={!hasSubmittedFeedback}
              title={!hasSubmittedFeedback ? "Please submit your feedback first" : "Download your session summary"}
              className={`font-medium px-8 py-3 rounded-full transition-all text-base flex items-center justify-center gap-2 min-w-[200px]
                      ${hasSubmittedFeedback
                  ? 'bg-emerald-500 hover:bg-emerald-600 text-white btn-glow cursor-pointer'
                  : 'bg-slate-100 text-slate-400 cursor-not-allowed border border-slate-200'}`}
            >
              Download Summary
              <Download size={20} />
            </button>

          </div>

        </div>

      </main>

      {/* 4. Feedback Popup Modal */}
      {showFeedback && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/60 backdrop-blur-sm px-4">
          <div className="bg-white border border-slate-200 rounded-xl p-8 max-w-md w-full shadow-2xl animate-in fade-in zoom-in duration-300 max-h-[100vh] overflow-y-auto custom-scrollbar">

            <h2 className="text-xl font-semibold text-slate-900 mb-2 text-center">How was your session?</h2>
            <p className="text-sm text-slate-500 mb-6 text-center font-light">Please rate your experience. Your feedback helps us improve.</p>

            {/* 1. Quality Rating */}
            <div className="mb-4">
              <p className="text-sm text-slate-700 mb-2 text-center">Quality of the content</p>
              <div className="flex gap-2 justify-center">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={`quality-${star}`}
                    type="button"
                    disabled={isSubmitting}
                    onClick={() => setQualityRating(star)}
                    className={`transition-transform hover:scale-110 focus:outline-none ${isSubmitting ? 'cursor-not-allowed opacity-50' : 'cursor-pointer'}`}
                  >
                    <Star
                      size={32}
                      className={`transition-colors ${star <= qualityRating ? "fill-emerald-500 text-emerald-500" : "text-slate-300"}`}
                    />
                  </button>
                ))}
              </div>
            </div>

            {/* 2. Accuracy Rating */}
            <div className="mb-4">
              <p className="text-sm text-slate-700 mb-2 text-center">Accuracy of the content</p>
              <div className="flex gap-2 justify-center">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={`accuracy-${star}`}
                    type="button"
                    disabled={isSubmitting}
                    onClick={() => setAccuracyRating(star)}
                    className={`transition-transform hover:scale-110 focus:outline-none ${isSubmitting ? 'cursor-not-allowed opacity-50' : 'cursor-pointer'}`}
                  >
                    <Star
                      size={32}
                      className={`transition-colors ${star <= accuracyRating ? "fill-emerald-500 text-emerald-500" : "text-slate-300"}`}
                    />
                  </button>
                ))}
              </div>
            </div>

            {/* 3. Avatar Experience Rating */}
            <div className="mb-6">
              <p className="text-sm text-slate-700 mb-2 text-center">Overall Avatar experience</p>
              <div className="flex gap-2 justify-center">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={`avatar-${star}`}
                    type="button"
                    disabled={isSubmitting}
                    onClick={() => setAvatarRating(star)}
                    className={`transition-transform hover:scale-110 focus:outline-none ${isSubmitting ? 'cursor-not-allowed opacity-50' : 'cursor-pointer'}`}
                  >
                    <Star
                      size={32}
                      className={`transition-colors ${star <= avatarRating ? "fill-emerald-500 text-emerald-500" : "text-slate-300"}`}
                    />
                  </button>
                ))}
              </div>
            </div>

            {/* Comments Textarea */}
            <textarea
              value={comments}
              onChange={(e) => setComments(e.target.value)}
              disabled={isSubmitting}
              placeholder="Enter notes/comments ..."
              className={`w-full bg-slate-50 border ${comments.trim() && !isValidComment(comments) ? 'border-red-500/50 focus:border-red-500' : 'border-slate-300 focus:border-emerald-500'} text-slate-900 placeholder-slate-400 focus:outline-none p-4 rounded-lg resize-none mb-2 h-24 custom-scrollbar text-sm transition-colors ${isSubmitting ? 'opacity-50 cursor-not-allowed' : ''}`}
            />
            {comments.trim() !== '' && !isValidComment(comments) && (
              <p className="text-red-500 text-xs mb-4 text-center">Please enter a meaningful comment.</p>
            )}
            {(!comments.trim() || isValidComment(comments)) && <div className="mb-6"></div>}

            {/* Submit Button */}
            {submitError && (
              <div className="mb-4 p-3 bg-red-500/10 text-red-400 text-xs rounded-md border border-red-500/20 text-center animate-in fade-in">
                {submitError}
              </div>
            )}

            <button
              onClick={handleFeedbackSubmit}
              disabled={isSubmitting || qualityRating === 0 || accuracyRating === 0 || avatarRating === 0 || !isValidComment(comments)}
              className={`w-full font-medium px-8 py-3 rounded-full transition-all text-base flex items-center justify-center gap-2 
                ${(qualityRating > 0 && accuracyRating > 0 && avatarRating > 0 && isValidComment(comments) && !isSubmitting)
                  ? 'bg-emerald-500 hover:bg-emerald-600 text-white btn-glow cursor-pointer'
                  : 'bg-slate-100 text-slate-400 cursor-not-allowed border border-slate-200'}`}
            >
              {isSubmitting ? (
                <>
                  Submitting...
                  <Loader2 className="animate-spin" size={20} />
                </>
              ) : (
                "Submit Feedback"
              )}
            </button>

          </div>
        </div>
      )}

    </div>
  );
}