'use client';
import { useState, useRef, useEffect } from 'react';
import { Download, PanelRightClose, Plus, Send, Paperclip, PanelRightOpen, MessageSquare } from 'lucide-react';
import { jsPDF } from 'jspdf';
import { SessionMessage } from '../types/types';
import {
  extractTextFromFile,
  sanitizeFileContent,
  detectPromptInjection,
  wrapIsolatedContent
} from '@/utils/security';

interface WorkspaceSidebarProps {
  chatOpen: boolean;
  setChatOpen: (open: boolean) => void;
  isSessionActive: boolean;
  messages: SessionMessage[];
  onSendMessage: (text: string, type?: 'text'|'code'|'file') => void;
}

export default function WorkspaceSidebar({
  chatOpen,
  setChatOpen,
  isSessionActive,
  messages,
  onSendMessage
}: WorkspaceSidebarProps) {
  
  const [isCodeMode, setIsCodeMode] = useState(false);
  const [inputText, setInputText] = useState("");
  // Flash error message state
  const [fileError, setFileError] = useState<string | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = () => {
    if (!inputText.trim()) return;
    onSendMessage(inputText, isCodeMode ? 'code' : 'text');
    setInputText("");
  };

  // --- File Upload Logic with Flash Error ---
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Allowed extensions including .pdf as explicitly mentioned in error message.
    const allowedFormats = ['.pdf', '.txt', '.js', '.py', '.java', '.json'];
    const fileExtension = file.name.split('.').pop()?.toLowerCase();
    const isValidFormat = fileExtension && allowedFormats.includes(`.${fileExtension}`);

    if (!isValidFormat) {
      // Set flash error message
      setFileError("Invalid file format. Please upload supported file formats such as .pdf, .txt");
      // Flash error mechanism: clear error after 3 seconds
      setTimeout(() => setFileError(null), 3000); 
      // Reset file input to allow uploading the same file again after error
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }

    // Security: Validate file size (e.g., max 5MB)
    const MAX_FILE_SIZE_MB = 5;
    if (file.size > MAX_FILE_SIZE_MB * 1024 * 1024) {
      setFileError(`File size exceeds the ${MAX_FILE_SIZE_MB}MB limit.`);
      setTimeout(() => setFileError(null), 3000);
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }

    try {
      const rawContent = await extractTextFromFile(file);

      // Security: Content filtering to detect prompt injection patterns
      const safetyCheck = detectPromptInjection(rawContent);
      if (safetyCheck.isInjected) {
        setFileError("Security Alert: Possible prompt injection detected. Upload blocked.");
        setTimeout(() => setFileError(null), 5000);
        if (fileInputRef.current) fileInputRef.current.value = '';
        return;
      }

      const sanitized = sanitizeFileContent(rawContent);
      const wrapped = wrapIsolatedContent(sanitized);

      const fileContextMsg = `I have uploaded a file named ${file.name}. Here is the isolated and sanitized content:\n\n${wrapped}`;
      onSendMessage(fileContextMsg, 'file');
    } catch (error) {
      console.error("Error processing uploaded file:", error);
      const errMsg = error instanceof Error ? error.message : "Failed to process the uploaded file.";
      const isSecurityAlert = errMsg.includes("Security Alert");
      setFileError(isSecurityAlert ? errMsg : "Failed to process the uploaded file.");
      setTimeout(() => setFileError(null), isSecurityAlert ? 5000 : 3000);
    } finally {
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  // --- Download Learnings Logic (PDF with Context + Chat) ---
  const handleDownloadLearnings = () => {
    const doc = new jsPDF();
    const margin = 20;
    const pageWidth = doc.internal.pageSize.getWidth();
    const maxLineWidth = pageWidth - margin * 2;
    let yPos = 20; 

    // Helper to add new pages if content overflows
    const checkPageBreak = (extraSpace = 0) => {
      if (yPos + extraSpace > doc.internal.pageSize.getHeight() - 20) {
        doc.addPage();
        yPos = 20;
      }
    };

    // --- Helper for Date Formatting ---
    const d = new Date();
    const dateNum = d.getDate();
    const nth = (day: number) => {
      if (day > 3 && day < 21) return 'th';
      switch (day % 10) {
        case 1:  return "st";
        case 2:  return "nd";
        case 3:  return "rd";
        default: return "th";
      }
    };
    const dateStr = `${dateNum}${nth(dateNum)} ${d.toLocaleString('default', { month: 'long' })} ${d.getFullYear()}`;
    const timeStr = d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true });

    // --- 1. Document Header ---
    // Centered Title
    doc.setFont("helvetica", "bold");
    doc.setFontSize(18);
    doc.setTextColor(0, 32, 96); // Dark blue
    const title = "Virtual Avatar Learnings";
    const titleWidth = doc.getTextWidth(title);
    doc.text(title, (pageWidth - titleWidth) / 2, yPos);
    yPos += 15;

    // Date and Timestamp Setup
    doc.setFontSize(11);
    doc.setTextColor(0, 0, 0);
    
    // Render Date
    doc.setFont("helvetica", "bold");
    doc.text("Date: ", margin, yPos);
    const dateLabelWidth = doc.getTextWidth("Date: ");
    doc.setFont("helvetica", "normal");
    doc.text(dateStr, margin + dateLabelWidth, yPos);
    
    // Render Timestamp
    doc.setFont("helvetica", "bold");
    const tsLabelWidth = doc.getTextWidth("Timestamp: ");
    doc.setFont("helvetica", "normal");
    const tsValWidth = doc.getTextWidth(timeStr);
    const totalTsWidth = tsLabelWidth + tsValWidth;
    const startX = pageWidth - margin - totalTsWidth;

    doc.setFont("helvetica", "bold");
    doc.text("Timestamp: ", startX, yPos);
    doc.setFont("helvetica", "normal");
    doc.text(timeStr, startX + tsLabelWidth, yPos);
    yPos += 10;

    // Fetch Context Data
    const contextStr = localStorage.getItem('virtual_facilitator_context');
    let contextData: any = {};
    if (contextStr) {
      try {
        contextData = JSON.parse(contextStr);
      } catch (err) {
        console.error("Failed to parse context for PDF", err);
      }
    }

    // Render Category
    const categoryVal = contextData.selectedCategory || "Technical"; 
    const formattedCategory = categoryVal.charAt(0).toUpperCase() + categoryVal.slice(1);
    
    doc.setFont("helvetica", "bold");
    doc.text("Category: ", margin, yPos);
    const catLabelWidth = doc.getTextWidth("Category: ");
    doc.setFont("helvetica", "normal");
    doc.text(formattedCategory, margin + catLabelWidth, yPos);
    yPos += 15;

    // 2. Learner Profile
    if (contextData.profile) {
      checkPageBreak(30);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(12);
      doc.text("Learner Profile:", margin, yPos);
      yPos += 7;
      
      doc.setFont("helvetica", "normal");
      doc.setFontSize(10);
      doc.text(`Name: ${contextData.profile.name}`, margin, yPos);
      yPos += 6;
      doc.text(`Role: ${contextData.profile.role} | Domain: ${contextData.profile.domain}`, margin, yPos);
      yPos += 6;
      doc.text(`Tech Stack: ${contextData.profile.techStack?.join(", ")}`, margin, yPos);
      yPos += 12;
    }

    // 3. Initial Q&A or File Upload
    if (contextData.submissionType === 'manual_qa' && contextData.data?.qa_pairs) {
      checkPageBreak(20);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(12);
      doc.text("Initial Q&A Setup:", margin, yPos);
      yPos += 8;
      
      doc.setFontSize(10);
      contextData.data.qa_pairs.forEach((pair: any) => {
        const qLines = doc.splitTextToSize(`Q: ${pair.question}`, maxLineWidth);
        qLines.forEach((line: string) => {
          checkPageBreak(6);
          doc.setFont("helvetica", "bold");
          doc.text(line, margin, yPos);
          yPos += 6;
        });
        
        const aLines = doc.splitTextToSize(`A: ${pair.answer}`, maxLineWidth);
        aLines.forEach((line: string) => {
          checkPageBreak(6);
          doc.setFont("helvetica", "normal");
          doc.text(line, margin, yPos);
          yPos += 6;
        });
        yPos += 4; 
      });
      yPos += 8;
    } else if (contextData.submissionType === 'file_upload' && contextData.data?.fileContent) {
      checkPageBreak(20);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(12);
      doc.text("Uploaded Context Summary:", margin, yPos);
      yPos += 8;
      
      doc.setFont("helvetica", "normal");
      doc.setFontSize(10);
      const fileLines = doc.splitTextToSize(contextData.data.fileContent, maxLineWidth);
      fileLines.forEach((line: string) => {
        checkPageBreak(6);
        doc.text(line, margin, yPos);
        yPos += 6;
      });
      yPos += 8;
    }

    // 4. Current Chat Messages
    if (messages.length > 0) {
      checkPageBreak(20);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(12);
      doc.text("Session Conversation:", margin, yPos);
      yPos += 8;
      
      messages.forEach((msg) => {
        const role = msg.role === 'user' ? 'Me' : 'VIRTUAL FACILITATOR';
        const time = new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        
        checkPageBreak(6);
        doc.setFont("helvetica", "bold");
        doc.setFontSize(11);
        doc.text(`[${time}] ${role}:`, margin, yPos);
        yPos += 7;

        doc.setFont("helvetica", "normal");
        doc.setFontSize(10);
        
        const splitText = doc.splitTextToSize(msg.content, maxLineWidth);
        splitText.forEach((line: string) => {
          checkPageBreak(6);
          doc.text(line, margin, yPos);
          yPos += 6;
        });
        yPos += 5; 
      });
    } else {
      checkPageBreak(10);
      doc.setFont("helvetica", "italic");
      doc.setFontSize(10);
      doc.text("No conversation history yet.", margin, yPos);
    }

    // Save the PDF
    const fileDay = d.getDate().toString().padStart(2, '0');
    const fileMonth = (d.getMonth() + 1).toString().padStart(2, '0');
    const fileYear = d.getFullYear();
    const fileDateStr = `${fileDay}-${fileMonth}-${fileYear}`;
    
    const fileTimeStr = d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true })
      .replace(/:/g, '-')
      .replace(/ /g, '_');
      
    doc.save(`Virtual_Avatar_Learnings_${fileDateStr}_${fileTimeStr}.pdf`);
  };

  return (
    <aside 
      className={`${chatOpen ? 'w-[450px] border-l border-slate-200' : 'w-20 border-transparent'} bg-white transition-all duration-300 flex flex-col z-30 flex-shrink-0 relative overflow-hidden`}
    >
      {/* MINIMIZED STATE: Persistent Icon */}
      {!chatOpen && (
        <div className="flex-grow flex flex-col items-center pt-20">
          <button 
              onClick={() => isSessionActive && setChatOpen(true)}
              disabled={!isSessionActive}
              className={`p-3 rounded-xl transition-all flex items-center justify-center group
                ${isSessionActive 
                  ? 'bg-slate-100 text-slate-800 hover:bg-emerald-500 hover:text-white shadow-sm cursor-pointer' 
                  : 'text-slate-400 cursor-not-allowed'}`}
              title={isSessionActive ? "Open Workspace" : "Start session to open workspace"}
          >
              <PanelRightOpen size={24} className={isSessionActive ? 'group-hover:scale-110 transition-transform' : ''} />
          </button>
        </div>
      )}

      {/* EXPANDED STATE: Full Chat Interface */}
      {chatOpen && (
        <>
          <div className="pt-15"></div>

          <header className="flex flex-col px-6 pt-4 pb-2 border-b border-slate-200 min-w-[450px]">
              {/* Top Row: Title/Toggles & Actions */}
              <div className="flex items-center justify-between w-full">
                  <div className="flex items-center gap-3">
                      <span className="text-emerald-600 font-bold text-lg tracking-wide">VIRTUAL FACILITATOR</span>
                      <div className="flex bg-slate-100 rounded-md p-1 gap-1">
                          <button 
                            onClick={() => setIsCodeMode(false)}
                            className={`w-6 h-6 rounded text-xs flex items-center justify-center font-bold transition-colors cursor-pointer
                              ${!isCodeMode ? 'bg-emerald-500 text-white shadow-sm' : 'text-slate-500 hover:text-slate-900'}`}
                          >
                            A
                          </button>
                          <button 
                            onClick={() => setIsCodeMode(true)}
                            className={`w-6 h-6 rounded text-xs flex items-center justify-center transition-colors cursor-pointer
                              ${isCodeMode ? 'bg-emerald-500 text-white shadow-sm' : 'text-slate-500 hover:text-slate-900'}`}
                          >
                              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="16 18 22 12 16 6"></polyline><polyline points="8 6 2 12 8 18"></polyline></svg>
                          </button>
                      </div>
                  </div>

                  <div className="flex items-center gap-4 text-xs text-slate-500">
                      <button 
                        onClick={handleDownloadLearnings} 
                        className="flex items-center gap-2 hover:text-slate-900 transition-colors cursor-pointer"
                      >
                          Download learnings
                          <Download size={16} />
                      </button>
                      <button onClick={() => setChatOpen(false)} className="text-slate-600 hover:text-slate-900 cursor-pointer" title="Minimize Workspace">
                          <PanelRightClose size={20} />
                      </button>
                  </div>
              </div>

              {/* Bottom Row: Tagline positioned below both VIRTUAL FACILITATOR and Download learnings */}
              <div className="mt-1 text-center">
                  <span className="text-red-500 text-xs leading-tight font-medium tracking-tight whitespace-normal">
                    Put your learning into action by sharing topics or files for personalized training
                  </span>
              </div>
          </header>

          <div className="flex-grow overflow-y-auto p-6 flex flex-col gap-8 custom-scrollbar min-w-[450px]">
              {messages.length === 0 ? (
                <div className="flex-grow flex flex-col items-center justify-center text-slate-400 text-sm gap-3">
                  <MessageSquare size={32} className="opacity-50" />
                  <p>No messages yet.</p>
                  <p className="text-center text-xs opacity-70">Type text, code, or upload files to interact.</p>
                </div>
              ) : (
                messages.map((msg) => (
                  <div key={msg.id} className={`flex items-start gap-4 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs flex-shrink-0 text-white shadow-sm ${msg.role === 'user' ? 'bg-purple-500' : 'bg-emerald-500'}`}>
                          {msg.role === 'user' ? 'Me' : 'V.'}
                      </div>
                      <div className="flex flex-col gap-3 max-w-[85%]">
                          {msg.role === 'user' ? (
                              <div className="bg-slate-100 border border-slate-200 rounded-lg p-4 shadow-sm">
                                  {msg.type === 'file' && (
                                    <div className="flex items-center gap-2 mb-2 text-emerald-600">
                                      <Paperclip size={14} /> <span className="text-xs font-semibold">File Uploaded</span>
                                    </div>
                                  )}
                                  <p className={`text-xs text-slate-700 leading-relaxed whitespace-pre-wrap ${msg.type === 'code' ? 'font-mono text-emerald-700 font-semibold' : ''}`}>
                                      {msg.content}
                                  </p>
                              </div>
                          ) : (
                              <p className="text-sm text-slate-600 leading-relaxed font-light whitespace-pre-wrap">
                                  {msg.content}
                              </p>
                          )}
                      </div>
                  </div>
                ))
              )}
              <div ref={messagesEndRef} />
          </div>

          <div className="p-4 bg-white border-t border-slate-200 min-w-[450px]">
              {/* Flash Error UI for Invalid File Upload */}
              {fileError && (
                  <div className="mb-3 p-3 bg-red-50 text-red-600 text-xs rounded-md border border-red-200 animate-pulse">
                    {fileError}
                  </div>
              )}
              <div className="bg-slate-100 rounded-md flex items-end px-4 py-3 gap-3">
                  {/* Updated tooltip for Plus sign */}
                  <button onClick={() => fileInputRef.current?.click()} className="text-slate-500 hover:text-slate-900 transition-colors pb-1 cursor-pointer" title="Click to upload your files here">
                      <Plus size={20} />
                  </button>
                  {/* Added .pdf to accept formats */}
                  <input type="file" accept=".pdf,.txt,.js,.py,.java,.json" className="hidden" ref={fileInputRef} onChange={handleFileUpload} />
                  
                  {/* Updated placeholders for both modes */}
                  <textarea 
                      value={inputText}
                      onChange={(e) => setInputText(e.target.value)}
                      placeholder={isCodeMode ? "Paste your code directly into the input area" : "Use the text field to type."} 
                      className={`bg-transparent flex-grow text-sm text-slate-900 placeholder-slate-400 focus:outline-none resize-none max-h-32 custom-scrollbar
                        ${isCodeMode ? 'font-mono' : ''}
                      `}
                      rows={Math.min(5, inputText.split('\n').length || 1)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' && !e.shiftKey) {
                          e.preventDefault();
                          handleSend();
                        }
                      }}
                  />

                  <button 
                    onClick={handleSend} 
                    disabled={!inputText.trim()}
                    className={`transition-colors pb-1 ${inputText.trim() ? 'text-emerald-600 cursor-pointer' : 'text-slate-400 cursor-not-allowed'}`}
                  >
                      <Send size={20} />
                  </button>
              </div>
          </div>
        </>
      )}
    </aside>
  );
}