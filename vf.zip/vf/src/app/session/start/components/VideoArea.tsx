'use client';
import { Loader2, Square, Mic } from 'lucide-react';
import BackButton from '@/components/BackButton';

interface VideoAreaProps {
  videoRef: React.RefObject<HTMLVideoElement | null>;
  isConnecting: boolean;
  isSessionActive: boolean;
  isMicActive: boolean;
  timeLeft: number;
  onStartSession: () => void;
  onEndSession: () => void;
}

export default function VideoArea({
  videoRef,
  isConnecting,
  isSessionActive,
  isMicActive,
  timeLeft,
  onStartSession,
  onEndSession
}: VideoAreaProps) {

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60).toString().padStart(2, '0');
    const s = (seconds % 60).toString().padStart(2, '0');
    return `00 : ${m} : ${s}`;
  };

  return (
    <main className="flex-grow relative bg-slate-50 overflow-hidden flex flex-col transition-all duration-300">
      
      <div className="absolute top-24 left-6 z-20">
        <BackButton />
      </div>

      <video 
          ref={videoRef}
          className="absolute top-0 left-0 w-full h-full object-cover z-0" 
          poster="/assets/avatar-preview.webp" 
          playsInline 
          autoPlay
          muted={!isSessionActive} 
      />
      <div className="absolute inset-0 bg-gradient-to-b from-black/10 via-transparent to-black/80 z-10 pointer-events-none"></div>

      <div className="absolute bottom-10 left-0 w-full flex justify-center z-20 px-4">
        <div className="bg-white/95 backdrop-blur-md border border-slate-200 rounded-full p-2 pr-8 pl-2 flex items-center gap-6 shadow-xl">
            
            {!isSessionActive ? (
                <button 
                    onClick={onStartSession}
                    disabled={isConnecting}
                    className={`bg-emerald-500 hover:bg-emerald-600 text-white font-medium px-10 py-3 rounded-full transition-all flex items-center justify-center min-w-[180px]
                        ${isConnecting ? 'opacity-80 cursor-not-allowed' : 'btn-glow cursor-pointer'}`}
                >
                    {isConnecting ? <><Loader2 className="animate-spin mr-2" size={18} /> Connecting...</> : 'Start Session'}
                </button>
            ) : (
                <div className="flex items-center gap-4">
                    <button 
                        onClick={onEndSession}
                        className="bg-red-50 hover:bg-red-100 border border-red-200 text-red-600 font-medium px-8 py-3 rounded-full transition-all flex items-center min-w-[160px] cursor-pointer"
                    >
                        <Square className="mr-2 fill-current" size={14} /> Stop Session
                    </button>
                    <div className={`p-3 rounded-full transition-all duration-300 ${isMicActive ? 'bg-emerald-100 text-emerald-600 scale-110' : 'bg-slate-100 text-slate-400'}`}>
                        <Mic size={20} className={isMicActive ? 'animate-pulse' : ''} />
                    </div>
                </div>
            )}

            <div className="flex flex-col items-end justify-center leading-tight border-l border-slate-200 pl-6 ml-2">
                <span className="text-[10px] text-slate-500 uppercase tracking-widest font-semibold">Total 25 Min</span>
                <span className={`text-xl font-light tracking-widest font-mono ${timeLeft < 300 ? 'text-red-500 animate-pulse font-semibold' : 'text-slate-800'}`}>
                    {formatTime(timeLeft)}
                </span>
            </div>
        </div>
      </div>
    </main>
  );
}