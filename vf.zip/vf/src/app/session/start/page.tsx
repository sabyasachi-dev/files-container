'use client';
import { useState, useRef, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Header from '@/components/Header';
import { basePath } from '@/utils/basePath';

import { AgentEventsEnum, LiveAvatarSession, SessionConfig, SessionEvent } from "@heygen/liveavatar-web-sdk";

import { SessionMessage } from './types/types';
import VideoArea from './components/VideoArea';
import WorkspaceSidebar from './components/WorkspaceSidebar';

export default function SessionStart() {
  const router = useRouter();

  const [avatar, setAvatar] = useState<LiveAvatarSession | null>(null);
  const [isConnecting, setIsConnecting] = useState(false);
  const [isSessionActive, setIsSessionActive] = useState(false);
  const [isMicActive, setIsMicActive] = useState(false);
  
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [timeLeft, setTimeLeft] = useState(25 * 60);

  const [chatOpen, setChatOpen] = useState(false);
  const [messages, setMessages] = useState<SessionMessage[]>([]);
  
  const currentAvatarMsgId = useRef<string | null>(null);
  const currentUserMsgId = useRef<string | null>(null);

  useEffect(() => {
    if (!isSessionActive) return;
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          handleEndSession(); 
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [isSessionActive]);

  useEffect(() => {
    if (messages.length > 0) {
      const existingContextStr = localStorage.getItem('virtual_facilitator_context');
      if (existingContextStr) {
        try {
          const existingContext = JSON.parse(existingContextStr);
          localStorage.setItem('virtual_facilitator_context', JSON.stringify({
              ...existingContext,
              session_history: messages
          }));
        } catch (e) {
          console.error("Failed to sync session history to local storage", e);
        }
      }
    }
  }, [messages]);

  async function fetchAccessToken() {
    try {
      const response = await fetch(`${basePath}/api/liveavatar/get-token`, { method: "POST" });
      if (!response.ok) throw new Error("Failed to fetch token");
      return await response.text();
    } catch (error) {
      console.error("Error fetching access token:", error);
      throw error;
    }
  }

  async function startSession() {
    setIsConnecting(true);
    try {
      const sessionToken = await fetchAccessToken();
      
      const userConfig: SessionConfig = { 
        voiceChat: true,
      };

      const newAvatar = new LiveAvatarSession(sessionToken, userConfig);

      newAvatar.on(SessionEvent.SESSION_STREAM_READY, () => {
        if (videoRef.current) {
          newAvatar.attach(videoRef.current);
        }
      });
      newAvatar.on(SessionEvent.SESSION_DISCONNECTED, handleEndSession);
      
      newAvatar.on(AgentEventsEnum.USER_SPEAK_STARTED as any, () => {
        setIsMicActive(true);
      });

      // ==========================================
      // --- USER VOICE (STT) MESSAGE AGGREGATION ---
      // ==========================================
      newAvatar.on(AgentEventsEnum.USER_TRANSCRIPTION as any, (event: any) => {
        const incomingText = event.text;
        if (!incomingText) return;

        if (!currentUserMsgId.current) {
          // Seal the Avatar's turn
          currentAvatarMsgId.current = null;

          const newId = Date.now().toString() + "-user";
          currentUserMsgId.current = newId;
          
          setMessages(prev => {
            const cleanedPrev = prev.filter(msg => msg.content.trim().length > 0);
            return [...cleanedPrev, {
              id: newId, role: 'user', type: 'text', content: incomingText, timestamp: new Date()
            }];
          });
        } else {
          setMessages(prev => prev.map(msg => 
            msg.id === currentUserMsgId.current ? { ...msg, content: incomingText } : msg
          ));
        }
      });

      newAvatar.on(AgentEventsEnum.USER_SPEAK_ENDED as any, () => {
        setIsMicActive(false);
        currentUserMsgId.current = null;
      });

      // ==========================================
      // --- AVATAR MESSAGE AGGREGATION ---
      // ==========================================
      newAvatar.on(AgentEventsEnum.AVATAR_TRANSCRIPTION as any, (event: any) => {
        const incomingText = event.text;
        if (!incomingText) return;

        if (!currentAvatarMsgId.current) {
          // Seal the User's turn
          currentUserMsgId.current = null;

          const newId = Date.now().toString() + "-avatar";
          currentAvatarMsgId.current = newId;
          
          setMessages(prev => {
            const cleanedPrev = prev.filter(msg => msg.content.trim().length > 0);
            return [...cleanedPrev, {
              id: newId, role: 'avatar', type: 'text', content: incomingText, timestamp: new Date()
            }];
          });
        } else {
          setMessages(prev => prev.map(msg => 
            msg.id === currentAvatarMsgId.current ? { ...msg, content: incomingText } : msg
          ));
        }
      });

      newAvatar.on(AgentEventsEnum.AVATAR_SPEAK_ENDED as any, () => {
        currentAvatarMsgId.current = null; 
      });

      await newAvatar.start();

      setAvatar(newAvatar);
      setIsSessionActive(true);

      const storedContextStr = localStorage.getItem('virtual_facilitator_context');
      if (storedContextStr) {
        try {
          const contextData = JSON.parse(storedContextStr);
          let contextPrompt = "";
          
          const categoryPrompt = contextData.selectedCategory 
            ? `My primary focus category for this session is ${contextData.selectedCategory}. ` 
            : "";
          
          if (contextData.submissionType === 'file_upload' && contextData.data?.fileContent) {
            contextPrompt = `${categoryPrompt}This is the last conversation: ${contextData.data.fileContent}. Please acknowledge this conversation explicitly and ask how we should continue.`;
          } else {
            contextPrompt = `Hello! Here is some background context about me for our session. ${categoryPrompt}`;
            if (contextData.profile) {
              contextPrompt += `I am ${contextData.profile.name}, working as a ${contextData.profile.role} in the ${contextData.profile.domain} domain. My tech stack includes ${contextData.profile.techStack?.join(", ")}. `;
            }
            if (contextData.submissionType === 'manual_qa' && contextData.data?.qa_pairs) {
              contextPrompt += "Here are some specific details about my project architecture: ";
              contextData.data.qa_pairs.forEach((pair: any) => {
                contextPrompt += `Regarding "${pair.question}", my answer is "${pair.answer}". `;
              });
            }
            contextPrompt += "Please use this information as context for my questions. Do not use a generic opening greeting. Instead, greet me as Virtual Facilitator, briefly summarize that you understand my background and focus area, and ask what we should focus on today!";
          }

          // REMOVED: Manual local injection of the initial context message.
          // It will now appear automatically when the server echoes it back.

          try {
            if (typeof newAvatar.interrupt === 'function') {
               await newAvatar.interrupt();
            }
          } catch (e) {}

          await newAvatar.message(contextPrompt);

        } catch (err) {
          console.error("Failed to parse or send context to avatar:", err);
        }
      }

    } catch (error) {
      console.error("Error starting avatar session:", error);
    } finally {
      setIsConnecting(false);
    }
  }

  async function handleEndSession() {
    if (avatar) {
      try { 
        await avatar.stop(); 
      } catch (e) {
        console.error("Error stopping session:", e);
      }
      setAvatar(null);
    }
    setIsSessionActive(false);
    setIsMicActive(false);
    router.push('/session/summary');
  }

  const handleSendMessage = async (text: string, type: 'text'|'code'|'file' = 'text') => {
    // REMOVED: Manual local injection of typed messages.
    // They will now appear automatically when the server echoes them back.
    if (avatar) {
      try {
        await avatar.message(text);
      } catch (e) {
        console.error("Failed to make avatar speak:", e);
      }
    }
  };

  return (
    <div className="flex flex-col h-screen w-screen bg-slate-50 overflow-hidden font-source-sans">
      <Header />

      <div className="flex-grow flex overflow-hidden relative">
        <VideoArea 
          videoRef={videoRef}
          isConnecting={isConnecting}
          isSessionActive={isSessionActive}
          isMicActive={isMicActive}
          timeLeft={timeLeft}
          onStartSession={startSession}
          onEndSession={handleEndSession}
        />

        <WorkspaceSidebar 
          chatOpen={chatOpen}
          setChatOpen={setChatOpen}
          isSessionActive={isSessionActive}
          messages={messages}
          onSendMessage={handleSendMessage}
        />
      </div>
    </div>
  );
}