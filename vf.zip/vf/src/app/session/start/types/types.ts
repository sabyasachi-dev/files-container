export interface SessionMessage {
    id: string;
    role: 'user' | 'avatar';
    type: 'text' | 'code' | 'file';
    content: string;
    timestamp: Date;
}