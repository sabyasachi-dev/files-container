import '@/lib/undici';
import { NextResponse } from "next/server";

export async function POST() {
  try {
    const LIVE_AVATAR_API_KEY = process.env.LIVE_AVATAR_API_KEY;
    const LIVE_AVATAR_SESSION_TOKEN_API_URL = process.env.LIVE_AVATAR_SESSION_TOKEN_API_URL;
    const LIVE_AVATAR_ID = process.env.LIVE_AVATAR_ID;
    const LIVE_AVATAR_VOICE_ID = process.env.LIVE_AVATAR_VOICE_ID;
    const LIVE_AVATAR_CONTEXT_ID = process.env.LIVE_AVATAR_CONTEXT_ID;

    // 1. Validate that all required environment variables exist
    if (!LIVE_AVATAR_API_KEY || !LIVE_AVATAR_SESSION_TOKEN_API_URL || !LIVE_AVATAR_ID || !LIVE_AVATAR_VOICE_ID || !LIVE_AVATAR_CONTEXT_ID) {
      console.error("Missing required environment variables.");
      return new NextResponse("Server configuration error", { status: 500 });
    }

    // 2. Build the payload cleanly in code, injecting the variables
    const requestPayload = {
      mode: 'FULL',
      avatar_id: LIVE_AVATAR_ID,
      video_settings: { quality: 'high', encoding: 'VP8' },
      max_session_duration: null,
      avatar_persona: {
        voice_id: LIVE_AVATAR_VOICE_ID,
        context_id: LIVE_AVATAR_CONTEXT_ID,
        language: 'en',
        voice_settings: {
          stability: 0.75,
          similarity_boost: 0.75,
          style: 0,
          use_speaker_boost: true,
          speed: 1,
          model: 'eleven_flash_v2_5'
        },
        stt_config: { provider: 'deepgram' }
      },
      interactivity_type: 'CONVERSATIONAL'
    };

    // 3. Make the fetch call
    const response = await fetch(LIVE_AVATAR_SESSION_TOKEN_API_URL, {
      method: "POST",
      headers: {
        "X-API-KEY": LIVE_AVATAR_API_KEY,
        "Content-Type": "application/json",
        "Accept": "application/json",
      },
      body: JSON.stringify(requestPayload)
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error("LiveAvatar Token Error:", errorText);
      return new NextResponse("Failed to fetch token", { status: response.status });
    }

    const json: any = await response.json();
    const sessionToken = json.data.session_token;

    return new NextResponse(sessionToken, { status: 200 });

  } catch (error) {
    console.error("Internal API Error:", error);
    return new NextResponse("Internal Server Error", { status: 500 });
  }
}