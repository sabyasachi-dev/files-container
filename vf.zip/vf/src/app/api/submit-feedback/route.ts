import '@/lib/undici';
import { NextResponse } from "next/server";
import { saveFeedback, FeedbackItem } from "@/lib/cosmos";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { qualityRating, accuracyRating, avatarRating, comments, profile } = body;

    // 1. Validate required fields and types
    if (
      typeof qualityRating !== "number" ||
      qualityRating < 1 ||
      qualityRating > 5 ||
      typeof accuracyRating !== "number" ||
      accuracyRating < 1 ||
      accuracyRating > 5 ||
      typeof avatarRating !== "number" ||
      avatarRating < 1 ||
      avatarRating > 5
    ) {
      return NextResponse.json(
        { error: "Invalid ratings. Ratings must be numbers between 1 and 5." },
        { status: 400 }
      );
    }

    if (typeof comments !== "string") {
      return NextResponse.json(
        { error: "Invalid comments. Comments must be a string." },
        { status: 400 }
      );
    }

    // 2. Prepare database payload
    const feedbackItem: FeedbackItem = {
      qualityRating,
      accuracyRating,
      avatarRating,
      comments: comments.trim(),
      profile: profile || null,
      timestamp: new Date().toISOString(),
    };

    // 3. Save to Cosmos DB (or mock fallback if env vars are missing)
    const result = await saveFeedback(feedbackItem);

    return NextResponse.json(
      { success: true, message: "Feedback submitted successfully.", data: result },
      { status: 200 }
    );
  } catch (error: any) {
    console.error("[API ERROR] Error in submit-feedback API route:", error);
    return NextResponse.json(
      { error: error.message || "Internal server error." },
      { status: 500 }
    );
  }
}
