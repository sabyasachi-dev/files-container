import '@/lib/undici';
import { NextResponse } from 'next/server';
import { headers } from 'next/headers';
import fs from 'fs';
import path from 'path';

export async function GET(request?: Request) {
  // Exchange access token with Graph API to get profile details
  const headersList = await headers();
  const authHeader = headersList.get('x-access-token');

  if (authHeader) {
    try {
      const graphApiUrl = process.env.GRAPH_API_URL || 'https://graph.microsoft.com/v1.0/me';
      const graphResponse = await fetch(graphApiUrl, {
        headers: {
          'Authorization': `Bearer ${authHeader}`
        }
      });
      if (graphResponse.ok) {
        const data = await graphResponse.json();

        // Map Graph API response to our app's profile structure
        const initials = data.displayName
          ? data.displayName.split(' ').map((n: string) => n[0]).join('').substring(0, 2).toUpperCase()
          : 'U';

        // Determine psId
        let psId = "unknown";
        if (data.userPrincipalName) {
          const localPart = data.userPrincipalName.split('@')[0];
          const nameParts = localPart.split(".");
          if (nameParts.length > 1) {
            psId = nameParts[nameParts.length - 1];
          } else {
            psId = localPart;
          }
        }

        return NextResponse.json({
          id: data.id || "unknown",
          psId: psId,
          name: data.displayName || "Unknown User",
          email: data.mail || data.userPrincipalName || "",
          designation: data.jobTitle || "",
          initials: initials
        });
      } else {
        console.warn('Graph API returned non-ok status:', graphResponse.status);
      }
    } catch (err) {
      console.error('Failed to fetch from Graph API:', err);
    }
  }

  // Fallback: For now, get data from user-profile.json
  const filePath = path.join(process.cwd(), 'public', 'json', 'user-profile.json');
  try {
    const fileContents = fs.readFileSync(filePath, 'utf8');
    const data = JSON.parse(fileContents);
    return NextResponse.json(data);
  } catch (error) {
    console.error('Error reading profile.json:', error);
    return NextResponse.json({ error: 'Failed to read profile' }, { status: 500 });
  }
}
