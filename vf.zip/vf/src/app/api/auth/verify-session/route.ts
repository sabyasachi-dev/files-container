import { NextResponse } from 'next/server';
import { Redis } from 'ioredis';

// Connect to the local Windows Redis Service using env variables
// This file runs in the Node.js runtime, so ioredis and TCP sockets work perfectly!
const redisOptions: any = {
  host: process.env.REDIS_HOST || '127.0.0.1',
  port: parseInt(process.env.REDIS_PORT || '6379', 10),
};

if (process.env.REDIS_PASSWORD) {
  redisOptions.password = process.env.REDIS_PASSWORD;
}

if (process.env.REDIS_TLS === 'true') {
  redisOptions.tls = {
    servername: process.env.REDIS_HOST,
  };
}

const redis = new Redis(redisOptions);

export async function POST(request: Request) {
  try {
    const { email, deviceId, isNewSession } = await request.json();
    const redisKey = `active_session:${email}`;

    if (isNewSession) {
      // SCENARIO: First time logging in on this device
      await redis.set(redisKey, deviceId);
      return NextResponse.json({ valid: true });
    }

    // SCENARIO: Existing session - Validate against Redis
    const currentActiveId = await redis.get(redisKey);

    if (currentActiveId && currentActiveId !== deviceId) {
      // KICKED: The ID in Redis does not match this browser's cookie.
      // This means they logged in somewhere else.
      return NextResponse.json({ valid: false });
    }

    // All good, session matches!
    return NextResponse.json({ valid: true });

  } catch (error) {
    console.error('Redis verification error:', error);
    // Fail open if Redis crashes to prevent locking users out
    return NextResponse.json({ valid: true }, { status: 500 });
  }
}
