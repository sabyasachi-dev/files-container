import '@/lib/undici';
import { NextResponse } from 'next/server';
import { GET as getUserProfile } from '../user-profile/route';
import fs from 'fs';
import path from 'path';

// Define a type for the profile response
interface Profile {
  name: string;
  role: string;
  domain: string;
  techStack: string[];
}

export async function GET(request: Request) {
  // For now, get data from digital-profile.json
  const filePath = path.join(process.cwd(), 'public', 'json', 'digital-profile.json');
  try {
    const fileContents = fs.readFileSync(filePath, 'utf8');
    const data = JSON.parse(fileContents);

    let email = data.email || '';
    let userId = data.userId || '';
    let psId = data.psId || '';

    // Dynamically update digital profile fields with active user profile details if available
    try {
      const profileResponse = await getUserProfile(request);
      if (profileResponse.ok) {
        const profileData = await profileResponse.json();
        console.log('Graph API response:', profileData);
        // Typically MS Entra returns userPrincipalName or email
        email = profileData.email || profileData.userPrincipalName || email;
        userId = profileData.id || userId;
        psId = profileData.psId || psId;
      }
    } catch (profileError) {
      console.warn('Could not retrieve user profile for digital profile mapping:', profileError);
    }

    console.log(`Fetching digital profile for psId: ${psId}`);
    let respprofile: Profile | null = null;
    try {
      const response = await fetch(`${process.env.DIGITAL_PROFILE_API_URL}?empId=${psId}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'x-api-key': process.env.DIGITAL_PROFILE_API_KEY || '',
        }
      });

      if (!response.ok) {
        throw new Error(`Error: ${response.status}`);
      }

      const data = await response.json();

      // Mapping the boomi response to the local state structure
      if (data && data.length > 0) {
        const profile = data[0];
        respprofile = {
          name: profile.NAME || '',
          role: profile.DESIGNATION || '',
          domain: profile.DESIGNATION || '',
          techStack: profile.skillClusterName ? [profile.skillClusterName] : []
        }
      }
    } catch (error) {
      console.error("Failed to fetch profile from Boomi:", error);
    }

    // Always return a consitent structure
    return NextResponse.json({
      email,
      userId,
      psId,
      profile: respprofile || data.profile || null
    });
  } catch (error) {
    console.error('Error reading digital-profile.json:', error);
    return NextResponse.json({ error: 'Failed to read digital profile' }, { status: 500 });
  }
}
