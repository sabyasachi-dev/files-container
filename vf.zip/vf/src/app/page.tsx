'use client';
import Link from 'next/link';
import Image from 'next/image';
import Header from '@/components/Header'; // Import global Header

export default function Home() {
  return (
    <main className="relative bg-slate-50 text-slate-900 overflow-x-hidden">
      
      {/* 1. Global Header (Handles its own scroll logic & menu icon internally) */}
      <Header />

      {/* 2. Background Graphic (Fixed Position) */}
      <div className="fixed top-0 left-0 h-screen w-full md:w-[60%] z-0 pointer-events-none opacity-90">
         <div className="relative w-full h-full">
            {/* Make sure 'ai-head2.png' is in your public/assets folder */}
            <Image 
              src="/assets/phoebe-hero.png" 
              alt="Virtual Facilitator Hero Graphic" 
              fill 
              className="object-cover object-center transition-transform duration-700 ease-out opacity-90"
              priority
            />
            {/* Gradient Overlay to blend image into black background */}
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-transparent to-slate-50"></div>
         </div>
      </div>

      {/* 3. Main Content Container */}
      <div className="relative z-10 max-w-[1600px] mx-auto px-6 md:px-20">
        
        {/* Section A: Hero (Top Part) */}
        <section className="min-h-screen flex flex-col justify-center items-end pb-20 pt-28">
            <div className="w-full md:w-1/2 lg:w-[45%] pl-4 md:pl-10">
                <h1 className="text-5xl md:text-7xl font-extralight leading-tight mb-6">
                    Where questions <br/> 
                    <span className="font-light">meet clarity</span>
                </h1>
                
                <p className="text-lg md:text-xl text-slate-600 font-light mb-10 max-w-md leading-relaxed">
                    Your Virtual Avatar for Technical <br/> & Domain Training
                </p>

                <Link 
                  href="/terms" 
                  className="inline-block bg-[#10b981] hover:bg-emerald-600 text-white font-bold text-sm tracking-wider px-10 py-4 rounded-full transition-all btn-glow uppercase"
                >
                    Get Started
                </Link>
            </div>
        </section>

        {/* Section B: Welcome (Bottom Part) */}
        <section className="min-h-[80vh] flex flex-col justify-center items-end pb-20">
            <div className="w-full md:w-1/2 lg:w-[45%] pl-8 md:pl-10 border-l-4 border-[#10b981]">
                <h2 className="text-4xl md:text-5xl font-light leading-tight mb-8">
                    Welcome to <br/>
                    the AI era
                </h2>
                
                <p className="text-slate-500 text-lg font-light leading-relaxed max-w-xl">
                    Virtual Facilitator is an intelligent, avatar-based virtual assistant designed to train associates on specific technical and domain topics. Acting as a real-time, knowledgeable guide, it provides personalized training, instant insights, and interactive learning experiences tailored to your needs.
                    <br/><br/>
                    With its interactive avatar experience, associates can seamlessly engage, explore new concepts, and upskill more effectively—driving faster learning, improved productivity, and a smarter way of training.
                </p>
            </div>
        </section>

      </div>
    </main>
  );
}