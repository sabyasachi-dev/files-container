'use client';
import { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import Header from '@/components/Header';
import BackButton from '@/components/BackButton';
import { Eye, X } from 'lucide-react';

export default function IntroPage() {
  const [isPopupOpen, setIsPopupOpen] = useState(false);

  const togglePopup = () => {
    setIsPopupOpen(!isPopupOpen);
  };

  const guidelines = [
    "Ask clear, concise, and focused questions to receive the most effective responses.",
    "Use the avatar strictly for technical and domain-related training.",
    "Please avoid ethical or moral dilemma-based questions.",
    "Engage with the Virtual Facilitator as a continuous companion for training, learning, and skill development throughout your journey."
  ];

  return (
    <div className="min-h-screen relative bg-slate-50 font-source-sans flex flex-col">
      
      {/* 1. Background Image with Blur Effect */}
      <div className="absolute inset-0 z-0 overflow-hidden">
        <Image 
          src="/assets/avatar-preview.webp" 
          alt="Background" 
          fill 
          className="object-cover filter blur-[8px] brightness-[0.35] scale-110"
          priority
        />
      </div>

      {/* 2. Standardized Header */}
      <Header />

      {/* 3. Main Content Overlay */}
      <div className="relative z-10 flex-1 flex flex-col pt-24 px-8">
        
        {/* Reusable Back Button (Aligned Left) */}
        <BackButton />

        {/* Centered Introduction Card */}
        <main className="flex-grow flex items-center justify-center pb-12">
          <div className="bg-white border border-slate-200 rounded-lg p-10 max-w-2xl w-full shadow-lg relative">
            
            {/* Label and View Icon */}
            <div className="flex items-center justify-between mb-4">
              <div className="text-xs font-bold text-slate-500 uppercase tracking-widest">
                INTRODUCTION
              </div>
              <button 
                onClick={togglePopup}
                className="text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
                title="View Guidelines"
              >
                <Eye size={18} />
              </button>
            </div>

            {/* Title */}
            <h1 className="text-4xl font-bold text-slate-900 mb-6">
              Hi! I'm Virtual Facilitator, your personal virtual facilitator.
            </h1>

            {/* Paragraph Content */}
            <p className="text-slate-600 leading-relaxed font-light mb-10 text-lg text-left">
              Think of me as your trusted tech & domain trainer—always ready to help you learn and sharpen your skills. Whether you're mastering a complex concept or exploring a new topic, I'm here to train you with clear, simple, and easy-to-follow lessons. I tailor my training to your experience level, offering practical insights that help you upskill with confidence and efficiency. Whenever you're ready to learn something new, just ask—I'm here to guide your learning journey!
            </p>

            {/* Action Button */}
            <Link 
              href="/session/start" 
              className="inline-block bg-[#10b981] hover:bg-emerald-600 text-white font-medium px-8 py-3 rounded-full transition-all transform hover:scale-105 btn-glow cursor-pointer"
            >
              Start Session
            </Link>

          </div>
        </main>
      </div>

      {/* Guidelines Popup */}
      {isPopupOpen && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-6 animate-in fade-in" 
          onClick={togglePopup}
        >
          <div 
            className="bg-white border border-slate-200 rounded-lg p-10 max-w-2xl w-full shadow-2xl relative animate-in zoom-in-95"
            onClick={(e) => e.stopPropagation()} // Prevent clicks inside the popup from closing it
          >
            {/* Close Button */}
            <button 
              onClick={togglePopup}
              className="absolute top-6 right-6 text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
              title="Close Guidelines"
            >
              <X size={20} />
            </button>

            {/* Title */}
            <h2 className="text-2xl font-semibold text-slate-900 mb-8">
              Guidelines
            </h2>

            {/* Guidelines List */}
            <ul className="list-disc list-outside pl-5 space-y-4 text-slate-600 leading-relaxed font-light text-lg text-left">
              {guidelines.map((guideline, index) => (
                <li key={index}>
                  {guideline}
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </div>
  );
}