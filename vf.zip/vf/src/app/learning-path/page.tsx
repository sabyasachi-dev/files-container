'use client';
import Header from '@/components/Header';
import BackButton from '@/components/BackButton';
import Link from 'next/link';
import { ArrowRight } from 'lucide-react';

export default function LearningPath() {
  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-source-sans">
      {/* 1. Standardized Black Header */}
      <Header />

      <div className="pt-24 px-8 pb-8 flex-grow flex flex-col">
        {/* 2. Break-out Back Button (Aligned Left) */}
        <BackButton />

        <main className="flex-grow flex flex-col justify-center items-center">
          {/* Main Content Container (Centered 2xl) */}
          <div className="max-w-2xl w-full">

            <div className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-3">
              Session
            </div>

            {/* Updated Headline */}
            <h1 className="text-4xl font-bold mb-6">Select Learning path</h1>

            {/* Updated Bullet Points with Icons */}
            <div className="text-slate-600 leading-7 mb-12 text-lg font-light text-left">
              <ul className="list-disc pl-6 space-y-3">
                <li>
                  Starting something new? <ArrowRight className="inline-block mx-1 text-emerald-500" size={18} /> Choose New Session to begin a fresh learning experience tailored to your current needs.
                </li>
                <li>
                  Continuing your journey? <ArrowRight className="inline-block mx-1 text-emerald-500" size={18} /> Select Continue Previous Session and upload your latest Summary Report to seamlessly resume from where you last left off.
                </li>
              </ul>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row justify-center gap-4">

              {/* Pass 'continue' mode in the URL */}
              <Link
                href="/setup?mode=continue"
                className="border border-slate-300 text-slate-700 bg-white px-10 py-3 rounded-full font-medium transition-all hover:bg-slate-100 hover:border-slate-400 min-w-[220px] cursor-pointer text-center"
              >
                Continue Previous Session
              </Link>

              {/* Standard New Session */}
              <Link
                href="/setup?mode=new"
                className="bg-[#10b981] hover:bg-emerald-600 text-white px-10 py-3 rounded-full font-medium transition-all btn-glow min-w-[220px] text-center cursor-pointer"
              >
                Start New Session
              </Link>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}