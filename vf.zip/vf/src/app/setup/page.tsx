'use client';
import { useState, useRef, useEffect, Suspense } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import { Edit2, Upload, ChevronLeft, Trash2, Loader2 } from 'lucide-react';
import Header from '@/components/Header';
import BackButton from '@/components/BackButton';
import { basePath } from '@/utils/basePath';
import {
  extractTextFromFile,
  sanitizeFileContent,
  detectPromptInjection,
  wrapIsolatedContent
} from '@/utils/security';

// --- 1. DATA TYPES & STRUCTURES ---

interface LearnerProfile {
  name: string;
  role: string;
  domain: string;
  techStack: string[];
}

type QuestionType = 'radio' | 'text' | 'select';

interface Question {
  id: string;
  type: QuestionType;
  text: string;
  options: string[];
}

// Fixed Questions as per requirements
const FIXED_QUESTIONS: Question[] = [
  {
    id: 'q1',
    type: 'text',
    text: 'Which technology or domain do you want to focus on?',
    options: []
  },
  {
    id: 'q2',
    type: 'radio',
    text: 'Is this for Concept Learning or a live issue?',
    options: ['Concept Learning', 'Live Issue']
  }
];

interface QA_Pair {
  id: string;
  question: string;
  answer: string;
  category: 'domain' | 'technical';
}

interface UserContextData {
  profile: LearnerProfile;
  submissionType: 'file_upload' | 'manual_qa';
  selectedCategory?: 'domain' | 'technical';
  data: {
    fileContent?: string;
    qa_pairs?: QA_Pair[];
  };
  timestamp: string;
}

// Shared security functions are imported from '@/utils/security'

// --- 2. MAIN COMPONENT ---

export default function SetupPage() {
  return (
    <Suspense fallback={<div className="min-h-screen bg-slate-50" />}>
      <IntegratedSetup />
    </Suspense>
  );
}

function IntegratedSetup() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const mode = searchParams.get('mode');

  // State
  const [step, setStep] = useState(mode === 'continue' ? 0 : 1);
  const [activeTab, setActiveTab] = useState<'domain' | 'technical'>('domain');

  // Profile State
  const [learnerProfile, setLearnerProfile] = useState<LearnerProfile | null>(null);
  const [isLoadingProfile, setIsLoadingProfile] = useState(true);

  // File State
  const [fileName, setFileName] = useState<string | null>(null);
  const [fileContent, setFileContent] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Q&A State
  const [answers, setAnswers] = useState<Record<string, string>>({});

  // Derived Values
  const totalQuestions = FIXED_QUESTIONS.length;
  const activeQuestion = FIXED_QUESTIONS[step - 1];

  // VALIDATIONS
  const isCurrentQuestionAnswered = activeQuestion ? Boolean(answers[activeQuestion.id]) : false;
  const isAllQuestionsAnswered = FIXED_QUESTIONS.every(q => Boolean(answers[q.id]));


  // --- 3. API FETCH PROFILE ---
  useEffect(() => {
    const initializeSetup = async () => {
      try {
        setIsLoadingProfile(true);
        const response = await fetch(`${basePath}/api/digital-profile`);
        if (response.ok) {
          const data = await response.json();
          // Map digital profile to LearnerProfile structure
          const mappedProfile: LearnerProfile = {
            name: data.profile?.name || "Unknown User",
            role: data.profile?.role || "Developer",
            domain: data.profile?.domain || "Engineering",
            techStack: data.profile?.techStack || []
          };
          setLearnerProfile(mappedProfile);
        } else {
          console.error("Failed to fetch /api/digital-profile");
        }
      } catch (error) {
        console.error("Error fetching user profile from /api/digital-profile:", error);
      } finally {
        setIsLoadingProfile(false);
      }
    };

    initializeSetup();
  }, []);

  // --- 4. HANDLERS ---
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.type !== 'application/pdf') {
        alert('Please upload a valid .pdf file');
        return;
      }

      // Security: Validate file size (e.g., max 5MB)
      const MAX_FILE_SIZE_MB = 5;
      if (file.size > MAX_FILE_SIZE_MB * 1024 * 1024) {
        alert(`File size exceeds ${MAX_FILE_SIZE_MB}MB limit.`);
        return;
      }

      setFileName(file.name);

      try {
        const rawContent = await extractTextFromFile(file);

        // Security: Content filtering to detect prompt injection patterns
        const safetyCheck = detectPromptInjection(rawContent);
        if (safetyCheck.isInjected) {
          alert('Security Alert: Possible prompt injection detected in the uploaded file. The file has been rejected.');
          setFileName(null);
          setFileContent(null);
          if (fileInputRef.current) fileInputRef.current.value = '';
          return;
        }

        const sanitized = sanitizeFileContent(rawContent);
        const wrapped = wrapIsolatedContent(sanitized);
        setFileContent(wrapped);
      } catch (error) {
        console.error("Error extracting text from PDF:", error);
        const errMsg = error instanceof Error ? error.message : "Failed to extract text from the PDF file.";
        alert(errMsg.includes("Security Alert") ? errMsg : "Failed to extract text from the PDF file. Check console for details.");
        setFileName(null);
        setFileContent(null);
        if (fileInputRef.current) fileInputRef.current.value = '';
      }
    }
  };

  const handleClearFile = () => {
    setFileName(null);
    setFileContent(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleAnswerChange = (val: string) => {
    if (!activeQuestion) return;
    setAnswers(prev => ({ ...prev, [activeQuestion.id]: val }));
  };

  // --- Scenario A: Continue with File ---
  const handleContinueWithFile = () => {
    if (!fileContent || !learnerProfile) return;
    const payload: UserContextData = {
      profile: learnerProfile,
      submissionType: 'file_upload',
      selectedCategory: activeTab,
      data: { fileContent: fileContent },
      timestamp: new Date().toISOString()
    };
    localStorage.setItem('virtual_facilitator_context', JSON.stringify(payload));

    // REDIRECT TO SESSION START
    router.push('/session/start');
  };

  // --- Scenario B: Save Manual Q&A ---
  const handleSaveAnswers = () => {
    // Prevent saving if profile isn't loaded or questions are missing
    if (!learnerProfile || !isAllQuestionsAnswered) return;

    const formattedPairs: QA_Pair[] = FIXED_QUESTIONS.map(q => ({
      id: q.id,
      question: q.text,
      answer: answers[q.id],
      category: activeTab
    })).filter(q => q.answer);

    const payload: UserContextData = {
      profile: learnerProfile,
      submissionType: 'manual_qa',
      selectedCategory: activeTab,
      data: { qa_pairs: formattedPairs },
      timestamp: new Date().toISOString()
    };
    localStorage.setItem('virtual_facilitator_context', JSON.stringify(payload));

    // REDIRECT TO INTRO
    router.push('/intro');
  };

  const handleTabSwitch = (tab: 'domain' | 'technical') => {
    setActiveTab(tab);
    // Optional: Reset answers and step if you want them to start fresh when switching categories
    // setAnswers({}); 
    // setStep(1);
  };

  const handleNext = () => {
    if (step < totalQuestions) {
      setStep(step + 1);
    }
  };

  const handleBack = () => {
    if (step > 1) {
      setStep(step - 1);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-source-sans">
      <Header />

      <div className="pt-24 px-8 pb-12 flex-grow flex flex-col">
        <BackButton />

        <main className="flex-grow w-full max-w-3xl mx-auto">
          <div className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-2">
            CONTEXT SETUP
          </div>

          {/* 1. DYNAMIC PROFILE SECTION */}
          <section className="mb-10">
            <h2 className="text-2xl font-semibold mb-4">Learner profile</h2>
            <div className="bg-white rounded-lg p-6 relative shadow-sm border border-slate-200 min-h-[160px]">
              {isLoadingProfile ? (
                <div className="animate-pulse flex flex-col h-full justify-center">
                  <div className="h-6 bg-slate-200 rounded w-1/3 mb-4"></div>
                  <div className="space-y-2">
                    <div className="h-4 bg-slate-200 rounded w-1/4"></div>
                    <div className="h-4 bg-slate-200 rounded w-1/4"></div>
                  </div>
                  <div className="absolute top-6 right-6">
                    <Loader2 className="animate-spin text-slate-400" size={18} />
                  </div>
                </div>
              ) : learnerProfile ? (
                <>
                  <button className="hidden absolute top-6 right-6 text-slate-400 hover:text-slate-800 transition-colors cursor-pointer">
                    <Edit2 size={18} />
                  </button>
                  <h3 className="text-lg font-bold text-slate-900 mb-4">{learnerProfile.name}</h3>
                  <div className="grid grid-cols-[120px_1fr] gap-y-1 text-sm">
                    <div className="text-slate-500">Role:</div><div className="text-slate-800">{learnerProfile.role}</div>
                    <div className="text-slate-500">Domain:</div><div className="text-slate-800">{learnerProfile.domain}</div>
                    <div className="text-slate-500">Tech Stack:</div><div className="text-slate-800">{learnerProfile.techStack.join(', ')}</div>
                  </div>
                </>
              ) : (
                <div className="text-red-400">Failed to load profile.</div>
              )}
            </div>
          </section>

          {/* 2. UPLOAD SECTION */}
          {step === 0 && (
            <section className="animate-in fade-in duration-500">
              <h2 className="text-2xl font-semibold mb-4">Please upload the previous session report</h2>
              <div className="bg-white rounded-md flex items-center justify-between p-1 pl-4 border border-slate-200 shadow-sm mb-8">
                <span className="text-sm text-slate-500 truncate pr-4">{fileName || 'Browse (.pdf only)'}</span>
                <input type="file" accept=".pdf" ref={fileInputRef} onChange={handleFileChange} className="hidden" />
                {fileName ? (
                  <button onClick={handleClearFile} className="bg-red-500/10 hover:bg-red-500/20 text-red-500 flex items-center justify-center w-10 h-10 rounded-md transition-all cursor-pointer" title="Remove file">
                    <Trash2 size={18} />
                  </button>
                ) : (
                  <button onClick={() => fileInputRef.current?.click()} className="bg-emerald-500 hover:bg-emerald-600 text-white flex items-center gap-2 px-8 py-2 rounded-md text-sm font-medium transition-all cursor-pointer shadow-sm">
                    Upload <Upload size={16} />
                  </button>
                )}
              </div>
              <div className="flex justify-end">
                <button
                  onClick={handleContinueWithFile}
                  disabled={!fileName || isLoadingProfile || !fileContent}
                  className={`px-8 py-3 rounded-full font-medium transition-all text-center text-sm ${fileName && !isLoadingProfile && fileContent ? 'bg-emerald-500 hover:bg-emerald-600 text-white btn-glow cursor-pointer' : 'bg-slate-100 text-slate-400 cursor-not-allowed border border-slate-200'}`}
                >
                  Continue Previous Session
                </button>
              </div>
            </section>
          )}

          {/* 3. QUESTIONS SECTION */}
          {step > 0 && activeQuestion && (
            <section className="animate-in fade-in slide-in-from-bottom-4 duration-500">

              {/* SEPARATED CATEGORY SELECTION */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-6 bg-white border border-slate-200 rounded-lg p-4 shadow-sm">
                <h2 className="text-lg font-medium text-slate-700 mb-3 sm:mb-0">Select Category</h2>
                <div className="bg-slate-100 rounded-[4px] p-[2px] flex">
                  {(['domain', 'technical'] as const).map((tab) => (
                    <button
                      key={tab}
                      onClick={() => handleTabSwitch(tab)}
                      className={`px-8 py-2 text-sm rounded-[4px] transition-all cursor-pointer capitalize font-medium ${activeTab === tab ? 'bg-emerald-500 text-white shadow-sm' : 'text-slate-500 hover:text-slate-900'}`}
                    >
                      {tab}
                    </button>
                  ))}
                </div>
              </div>

              {/* QUESTION CARD */}
              <div className="border border-slate-200 rounded-lg p-8 md:p-12 min-h-[350px] flex flex-col relative bg-white shadow-md">
                <div key={activeQuestion.id} className="animate-in fade-in duration-300">
                  <p className="text-xl text-slate-700 leading-relaxed font-light mb-10">
                    {activeQuestion.text}
                  </p>

                  {/* LOGIC TO RENDER INPUTS */}
                  {activeQuestion.type === 'text' && (
                    <input
                      type="text"
                      value={answers[activeQuestion.id] || ''}
                      onChange={(e) => handleAnswerChange(e.target.value)}
                      placeholder="Type your answer here..."
                      className="w-full bg-white border border-slate-300 rounded-lg p-4 text-slate-900 focus:outline-none focus:border-emerald-500 transition-colors"
                    />
                  )}

                  {activeQuestion.type === 'radio' && (
                    <div className="flex flex-col sm:flex-row gap-6 max-w-2xl">
                      {activeQuestion.options.map((option) => {
                        const isSelected = answers[activeQuestion.id] === option;
                        return (
                          <label
                            key={option}
                            className={`flex-1 flex items-center justify-center py-4 px-6 rounded-lg cursor-pointer transition-all border text-center
                              ${isSelected
                                ? 'bg-emerald-500 border-emerald-500 text-white shadow-[0_0_15px_rgba(16,185,129,0.4)]'
                                : 'bg-white border-slate-300 text-slate-600 hover:border-slate-400 hover:text-slate-900'
                              }`}
                          >
                            <input
                              type="radio"
                              name={activeQuestion.id}
                              value={option}
                              checked={isSelected}
                              onChange={(e) => handleAnswerChange(e.target.value)}
                              className="hidden"
                            />
                            <span className="font-medium text-base tracking-wide">{option}</span>
                          </label>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>

              {/* NAVIGATION CONTROLS */}
              <div className="flex items-center justify-between mt-10">
                <button
                  onClick={handleBack}
                  disabled={step === 1}
                  className={`flex items-center gap-2 font-medium transition-colors ${step === 1 ? 'text-slate-400 cursor-not-allowed' : 'text-slate-900 hover:text-slate-600 cursor-pointer'}`}
                >
                  <ChevronLeft size={20} /> Previous
                </button>

                <div className="text-slate-900 font-medium tracking-widest text-sm">Question {step} of {totalQuestions}</div>

                {step < totalQuestions ? (
                  <button
                    onClick={handleNext}
                    disabled={!isCurrentQuestionAnswered}
                    className={`px-10 py-2.5 rounded-full font-medium transition-all text-center shadow-sm
                      ${!isCurrentQuestionAnswered
                        ? 'bg-slate-100 text-slate-400 border border-slate-200 cursor-not-allowed'
                        : 'bg-emerald-500 hover:bg-emerald-600 text-white cursor-pointer'}`}
                  >
                    Next
                  </button>
                ) : (
                  <button
                    onClick={handleSaveAnswers}
                    disabled={isLoadingProfile || !isAllQuestionsAnswered}
                    className={`px-10 py-2.5 rounded-full font-medium transition-all text-center
                      ${isLoadingProfile || !isAllQuestionsAnswered
                        ? 'bg-slate-100 text-slate-400 border border-slate-200 cursor-not-allowed'
                        : 'bg-emerald-500 hover:bg-emerald-600 text-white btn-glow cursor-pointer'}`}
                  >
                    Save
                  </button>
                )}
              </div>
            </section>
          )}
        </main>
      </div>
    </div>
  );
}