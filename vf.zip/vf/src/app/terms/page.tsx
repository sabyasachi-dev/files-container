'use client';
import Header from '@/components/Header';
import BackButton from '@/components/BackButton';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

export default function Terms() {
  const router = useRouter();

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-source-sans">
      <Header />

      <div className="pt-20 px-8 pb-6 flex-grow flex flex-col">
        {/* Back Button sits here, outside the main text block */}
        <BackButton />

        <main className="flex-grow flex flex-col justify-center items-center">
          {/* Main Content Container (Centered) */}
          <div className="max-w-2xl w-full">
            
            {/* Added as h2 tag like disclaimer */}
            <h2 className="text-xl font-bold text-slate-900 mb-4">Terms and Conditions</h2>

            {/* Tightened text sizing, line heights, and margins for a compact fit */}
            <div className="text-slate-600 leading-snug mb-8 text-base font-light text-left space-y-4">
                <ul className="list-disc pl-5 space-y-2">
                    <li>This is an AI-based facilitator avatar designed to provide training on specific technical and domain-related topics.</li>
                    <li>Guidance provided is informational and supportive, not a substitute for expert judgment or official decisions.</li>
                    <li>Validate all recommendations before applying them in real-world or production environments.</li>
                    <li>Do not share confidential, client-specific, personal, or proprietary information.</li>
                    <li>Ethical, legal, medical, financial, or moral dilemma questions are not permitted.</li>
                    <li>AI responses may be context-dependent, approximate, incomplete and not accurate as well.</li>
                </ul>
                
                <div className="pt-2">
                    <h2 className="text-xl font-bold text-slate-900 mb-2">Disclaimer</h2>
                    <p className="mb-2">
                        You are engaging with a Virtual Facilitator designed to deliver interactive training and a seamless, guided learning experience.
                    </p>
                    <p>
                        By continuing, you acknowledge that you are <span className="font-semibold text-slate-900">interacting with an AI system</span> and agree to responsible usage.
                    </p>
                </div>
            </div>

            {/* Buttons aligned to center */}
            <div className="flex flex-col sm:flex-row justify-center gap-4 mt-2">
                <button 
                  onClick={() => router.push('/')}
                  className="border border-slate-300 text-slate-700 bg-white px-8 py-2.5 rounded-full font-medium transition-all hover:bg-slate-100 hover:border-slate-400 min-w-[160px] cursor-pointer"
                >
                    I disagree
                </button>

                <Link 
                  href="/learning-path" 
                  className="bg-[#10b981] hover:bg-emerald-600 text-white px-8 py-2.5 rounded-full font-medium transition-all btn-glow min-w-[160px] text-center flex items-center justify-center cursor-pointer"
                >
                    I agree
                </Link>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}