import Header from "@/components/Header";
import AdminFeedback from "@/components/AdminFeedback";

export const metadata = {
  title: 'Admin - Feedback Management',
}

export default function AdminPage() {
  return (
    <main className="min-h-screen bg-[var(--background)] flex flex-col relative">
      <Header />
      <div className="flex-1 w-full relative z-10 pt-16">
        <AdminFeedback />
      </div>
      
      {/* Background decoration matching overall site feel */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none z-0">
        <div className="absolute top-[10%] left-[-10%] w-[40%] h-[40%] bg-blue-900/10 blur-[120px] rounded-full mix-blend-screen"></div>
        <div className="absolute bottom-[10%] right-[-10%] w-[40%] h-[40%] bg-[#ff5c4d]/10 blur-[120px] rounded-full mix-blend-screen"></div>
      </div>
    </main>
  );
}
